package com.nttdata.web.usecase1C.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.nttdata.web.common.CommonService;
import com.nttdata.web.model.ConfigBean;
import com.nttdata.web.model.MetricsBean;
import com.nttdata.web.model.PredictionBean;
import com.nttdata.web.model.ProjectBean;
import com.nttdata.web.model.ReleaseDetails;
import com.nttdata.web.model.UserBean;
import com.nttdata.web.service.ConfigService;
import com.nttdata.web.usecase1C.service.DefectCountService;
import com.nttdata.web.utils.ColorEnum;
import com.nttdata.web.utils.CrestaQueryConstants;
import com.nttdata.web.utils.Utils;

@Controller
public class DefectCountController {

	@Autowired
	private DefectCountService defectCountService;

	@Autowired
	private ConfigService configService;

	@Autowired
	private CommonService commonService;

	@RequestMapping(value = "/predictDefectCount", method = RequestMethod.POST)
	public ModelAndView predictUseCase1C(@ModelAttribute("configBean") ConfigBean configBean,
			HttpServletRequest request) {
		String predictionId = "7";
		int algorithmId = configBean.getAlgorithmBean().getAlgorithmId();
		List<MetricsBean> metricsList = configBean.getPredictBean().getMetricsList();
		return getPredictResult(metricsList, request, predictionId,algorithmId);
	}

	public ModelAndView getPredictResult(List<MetricsBean> metricsList, HttpServletRequest request,
			String predictionId,int algorithmId) {
		MetricsBean metricBean = metricsList.get(0);
		int[] ucl = metricBean.getUcl();
		int[] lcl = metricBean.getLcl();
		metricBean.setPredictionId(predictionId);
		HttpSession session = request.getSession();
		Integer redmineProjectId = (Integer) session.getAttribute("SELECTEDPROJECT");
		int parameterId = (int) session.getAttribute("SELECTEDTRENDPARAMETER");
		String predictionCode = (String) session.getAttribute("SELECTEDPREDICTION");
		UserBean userBean = (UserBean) session.getAttribute("USERBEAN");
		String userId = userBean.getUserId();

		commonService.saveData(metricBean);
		commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionCode);

		ModelAndView modelView = null;
		if (algorithmId == 1)
			modelView = new ModelAndView("predictionForAllAlgorithms");
		else
			modelView = new ModelAndView("prediction");

		int[][][] graphData = new int[6][][];
		graphData = defectCountService.processTask("predictUseCase1C", predictionCode, "NA", userId, redmineProjectId,
				ucl, lcl, algorithmId);
		
		int[][] actualData = new int[graphData.length][];
		actualData = graphData[4];
		
		List<Integer> defectCountList = new ArrayList<Integer>();
		List<Integer> releaseCountList = new ArrayList<Integer>();

		int[][] releaseData = new int[graphData.length][];
		releaseData = graphData[2];

		for (int i = 0; i < releaseData.length; i++) {
			int[] data = (int[]) releaseData[i];
			releaseCountList.add(data[0]);
			defectCountList.add(data[1]);

		}
		
		List<Integer> predictionList = new ArrayList<Integer>();
		int[][] predictedData = new int[graphData.length][];
		predictedData = graphData[3];

		for (int i = 0; i < predictedData.length; i++) {
			int[] data = (int[]) predictedData[i];
			predictionList.add(data[1]);
		}

		ConfigBean configBean = new ConfigBean();
		configBean.getProjectBean().setProjectName(commonService.getProjectName(redmineProjectId,
				(List<ProjectBean>) session.getAttribute("PROJECTLIST")));
		configBean.getPredictBean().setPredictDescription(commonService.getPredictionName(predictionCode,
				(List<PredictionBean>) session.getAttribute("PREDICTLIST")));
		configBean.getAlgorithmBean().setAlgorithmCode(commonService.getAlgorithmName(algorithmId));
		
		String resultString = null;
		if(algorithmId == 1){
			int graphData1[][][] = new int[6][][];
			graphData1[0] = graphData[0];
			graphData1[1] = graphData[1];
			graphData1[2] = graphData[2];
			graphData1[3] = graphData[3];
			graphData1[4] = graphData[4];
			graphData1[5] = graphData[5];
//			graphData1[6] = graphData[6];
			resultString = commonService.convertToJSON(graphData1);
		}else{
		int[][][] graphData1 = new int[4][][];
		graphData1[0] = graphData[0];
		graphData1[1] = graphData[1];
		graphData1[2] = graphData[2];
		graphData1[3] = graphData[3];
		resultString = commonService.convertToJSON(graphData1);
		}
		
		modelView.addObject("datasets", resultString);

		modelView.addObject("projectCode", redmineProjectId);
		modelView.addObject("parameterId", parameterId);
		modelView.addObject("predictionCode", predictionCode);
		modelView.addObject("userId", userId);
		modelView.addObject("configBean", configBean);
		int predictedValue = predictionList.get(predictionList.size() - 1);
		ColorEnum colorEnum = Utils.getColorEnum(ucl[0], lcl[0], predictedValue);
		modelView.addObject("predictionColour", colorEnum.getColorValue());
//		releaseCountList.add(releaseCountList.get(releaseCountList.size() - 1) + 1);
		releaseCountList.add(releaseCountList.get(releaseCountList.size() - 1));

		int maxDefect = Collections.max(defectCountList);
		maxDefect = (ucl[0] > maxDefect) ? ((ucl[0] > predictedValue) ? ucl[0] : predictedValue)
				: ((maxDefect > predictedValue) ? maxDefect : predictedValue);
		int lastStepY = CrestaQueryConstants.STEP_SIZE - (maxDefect % CrestaQueryConstants.STEP_SIZE);
		maxDefect = maxDefect + lastStepY;

		int minDefect = Collections.min(defectCountList);
		minDefect = lcl[0] < minDefect ? (lcl[0] < predictedValue ? lcl[0] : predictedValue)
				: (minDefect < predictedValue ? minDefect : predictedValue);
		int firstStep = minDefect % CrestaQueryConstants.STEP_SIZE;
		if (firstStep == 0 && minDefect >= CrestaQueryConstants.STEP_SIZE)
			minDefect = minDefect - CrestaQueryConstants.STEP_SIZE;
		else if (firstStep == 0 && minDefect < CrestaQueryConstants.STEP_SIZE)
			minDefect = 0;
		else
			minDefect = minDefect - firstStep;

		int maxRelease = Collections.max(releaseCountList);
		maxRelease = maxRelease+2;

		int minRelease = Collections.min(releaseCountList);

//		int actualValue = defectCountList.get(defectCountList.size() - 1);
		
//		int actualValue = actualList.get(actualList.size() - 1);
		
		int actualValue = actualData[0][0];
		
		List<Integer> getMaxValueList = new ArrayList<Integer>();
		getMaxValueList.add(actualValue);
		getMaxValueList.add(predictedValue);
		
		ReleaseDetails currentReleaseDetails = new ReleaseDetails();
		currentReleaseDetails.setRelease(releaseCountList.get(releaseCountList.size() - 1).toString());
		currentReleaseDetails.setActualValue(defectCountList.get(defectCountList.size() - 1).toString());
		currentReleaseDetails.setPredictedValue(Integer.toString(predictedValue));
		currentReleaseDetails.setAccuracy(CrestaQueryConstants.NOT_APPLICABLE);

		if(actualValue==0){
			System.out.println("No Accuracy result");
			currentReleaseDetails.setAccuracy("-");
			int val = releaseCountList.get(releaseCountList.size() - 1);
			int newRelease = val + 1;
			currentReleaseDetails.setRelease(""+newRelease);
		}else{
		double accuracy = 100 -(Math.abs(actualValue - predictedValue) * 100 / Collections.max(getMaxValueList));
		currentReleaseDetails.setActualValue(Integer.toString(actualValue));
		currentReleaseDetails.setPredictedValue(Integer.toString(predictedValue));
		currentReleaseDetails.setAccuracy(Double.toString(accuracy));
		}
		
		List<ReleaseDetails> releaseDetailsList = new ArrayList<ReleaseDetails>();
//		currentReleaseDetails.setRelease(releaseCountList.get(releaseCountList.size() - 1).toString());
		currentReleaseDetails.setActualValue(Integer.toString(actualValue));
		releaseDetailsList.add(currentReleaseDetails);
//		releaseDetailsList.add(nextReleaseDetails);

		modelView.addObject("maxYValue", maxDefect);
		modelView.addObject("minYValue", minDefect);
		modelView.addObject("maxXValue", maxRelease);
		modelView.addObject("minXValue", minRelease);
		modelView.addObject("xLabel", CrestaQueryConstants.RELEASE);
		modelView.addObject("yLabel", CrestaQueryConstants.ALL_DEFECTS);
		modelView.addObject("releaseDetails", releaseDetailsList);
		return modelView;
	}

}

