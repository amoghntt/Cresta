package com.nttdata.web.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Service
public class JubatusUtils {

	@Autowired
	ConfigurationUtils configurationUtils;

	public boolean startJubatus(String jubatusServer, String configpath, int jubatusPort) {
		boolean result = false;

		stopJubatus(jubatusPort);
		// System.out.println(configurationUtils.getJubatusConfigFilePath());

		// StringBuilder sb = new
		// StringBuilder(CrestaConstants.JUBATUS_SERVER_ENVIRONMENT_FILE);
		StringBuilder sb = new StringBuilder(configurationUtils.getJubatusServerEnvironmentFile());
		// StringBuilder sb = new
		// StringBuilder(configurationUtils.getJubatusServerEnvironmentFile());
		sb.append(" ");
		sb.append(jubatusServer);
		sb.append(" ");
		sb.append(" --configpath ");
		sb.append(configpath);
		sb.append(" --rpc-port ");
		sb.append(jubatusPort);
		sb.append(" & ");
		String startCommand = sb.toString();
		System.out.println(startCommand);

		try {
			JSch jsch = new JSch();
			Session session = jsch.getSession(configurationUtils.getJubtusServerUserName(),
					configurationUtils.getJubtusServerHostIp());

			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");

			session.setConfig(config);
			session.setPort(configurationUtils.getJubtusServerJschPort());
			session.setPassword(configurationUtils.getJubtusServerPassword());

			session.connect();
			Channel channel = session.openChannel("exec");

			((ChannelExec) channel).setCommand(startCommand);
			channel.connect();
			Thread.sleep(3000);

			channel.disconnect();
			session.disconnect();
			System.out.println(jubatusServer + " started on port " + jubatusPort);

			result = true;

		} catch (JSchException | InterruptedException e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean stopJubatus(int jubatusPort) {
		boolean result = false;

		String stopCommand = String.format("kill -9 $(lsof -t -i:%d)", jubatusPort);
		System.out.println(stopCommand);

		try {
			JSch jsch = new JSch();
			Session session = jsch.getSession(configurationUtils.getJubtusServerUserName(),
					configurationUtils.getJubtusServerHostIp());

			Properties config = new Properties();
			config.put("StrictHostKeyChecking", "no");

			session.setConfig(config);
			session.setPort(configurationUtils.getJubtusServerJschPort());
			session.setPassword(configurationUtils.getJubtusServerPassword());
			session.connect();

			Channel channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(stopCommand);
			channel.connect();

			Thread.sleep(1000);

			channel.disconnect();
			session.disconnect();
			System.out.println("Jubatus server stopped on port : " + jubatusPort);

			result = true;

		} catch (JSchException | InterruptedException e) {
			e.printStackTrace();
		}
		return result;
	}

	@SuppressWarnings("unused")
	public String readPropertiesFile(String key) {
		String propertyValue = null;
		try {

			// InputStream input = new
			// FileInputStream(CrestaQueryConstants.PROPERTIES_FILE_PATH);
			InputStream input = new FileInputStream(configurationUtils.getPropertiesFilePath());
			if (input == null) {
				System.out.println("Sorry, unable to find properties file");

			}
			Properties prop = new Properties();
			prop.load(input);
			propertyValue = prop.getProperty(key);
			System.out.println("Read value from config file " + propertyValue);

		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return propertyValue;
	}
}
