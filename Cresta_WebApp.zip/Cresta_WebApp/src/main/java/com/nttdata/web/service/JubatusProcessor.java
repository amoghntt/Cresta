package com.nttdata.web.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.msgpack.rpc.loop.EventLoop;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.pythonexecutor.Java2PythonExecutor;
import com.nttdata.pythonexecutor.ScikitConstants;
import com.nttdata.web.model.MetricsBean;
import com.nttdata.web.model.PredictedModel;
import com.nttdata.web.usecase1.service.FindDefectsServiceUseCase1;
import com.nttdata.web.usecase1A.service.FindDefectsServiceUseCase1A;
import com.nttdata.web.usecase1B.service.FindDefectsServiceUseCase1B;
import com.nttdata.web.usecase1C.service.FindDefectsServiceUseCase1C;
import com.nttdata.web.usecase1D.service.FindDefectsServiceUseCase1D;
import com.nttdata.web.usecase2.service.FindDefectsServiceUseCase2;
import com.nttdata.web.usecase3.model.DefectLeakageModel;
import com.nttdata.web.usecase3.service.FindDefectsServiceUseCase3;
import com.nttdata.web.utils.ConfigurationUtils;
import com.nttdata.web.utils.CrestaConstants;
import com.nttdata.web.utils.CrestaQueryConstants;
import com.nttdata.web.utils.JubatusUtils;

import us.jubat.stat.StatClient;

@Service
public class JubatusProcessor {

	private static final Logger log = LoggerFactory.getLogger(JubatusProcessor.class);

	@Autowired
	JubatusUtils jubatusUtils;

	@Autowired
	ConfigurationUtils configurationUtils;

	@Autowired
	FindDefectsServiceUseCase1 findDefectsUseCase1;

	@Autowired
	FindDefectsServiceUseCase2 findDefectsModuleWise;

	@Autowired
	FindDefectsServiceUseCase3 findDefectsForUseCase3;

	@Autowired
	FindDefectsServiceUseCase1D findDefectsForUseCase1D;

	@Autowired
	FindDefectsServiceUseCase1A findDefectsForUseCase1A;

	@Autowired
	FindDefectsServiceUseCase1B findDefectsUseCase1B;

	@Autowired
	FindDefectsServiceUseCase1C findDefectsUseCase1C;

	public List<Integer> predictDensity(int userId, String predictionCode) {
		List<Integer> resultList = new ArrayList<Integer>();
		try {
			// resultList.add(findDefects.predictData(userId,predictionCode));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public Map<String, PredictedModel> predictDensityModuleWise(int userId, String predictionCode) {
		Map<String, PredictedModel> resultList = new HashMap<String, PredictedModel>();
		try {
			resultList = findDefectsModuleWise.predictData(userId, predictionCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<Integer> predictDensityForUseCase3(int userId, String predictionCode) {
		List<Integer> resultList = new ArrayList<Integer>();
		try {
			resultList.add(findDefectsForUseCase3.predictData(userId, predictionCode));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<Integer> predictDensityForUseCase1D(int userId, String predictionCode) {
		List<Integer> resultList = new ArrayList<Integer>();
		try {
			resultList.add(findDefectsForUseCase1D.predictData(userId, predictionCode));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<Integer> predictDensityForUseCase1(int userId, String predictionCode) {
		List<Integer> resultList = new ArrayList<Integer>();
		try {
			resultList.add(findDefectsUseCase1.predictData(userId, predictionCode));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<Integer> predictDensityForUseCase1A(int userId, String predictionCode) {
		List<Integer> resultList = new ArrayList<Integer>();
		try {
			resultList.add(findDefectsForUseCase1A.predictData(userId, predictionCode));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<int[]> computeUclLclData(int metricsId, List<Integer> defectCount) {
		List<int[]> resultList = new LinkedList<int[]>();
		try {
			MetricsBean metricsBean = getCalculateLimit(metricsId, defectCount);
			int[] ucl;
			int[] lcl;

			ucl = metricsBean.getUcl();
			lcl = metricsBean.getLcl();
			resultList.add(lcl);
			resultList.add(ucl);
			jubatusUtils.stopJubatus(configurationUtils.getPORT());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<int[]> computeUclLclData1(int metricsId, List<DefectLeakageModel> defectCount) {
		List<int[]> resultList = new LinkedList<int[]>();
		try {
			MetricsBean metricsBean = getCalculateLimit1(metricsId, defectCount);
			int[] ucl;
			int[] lcl;

			ucl = metricsBean.getUcl();
			lcl = metricsBean.getLcl();
			resultList.add(lcl);
			resultList.add(ucl);
			jubatusUtils.stopJubatus(configurationUtils.getPORT());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<Integer> predictDefectDeferralRate(int userId, String predictionCode) {
		List<Integer> resultList = new ArrayList<Integer>();
		try {
			resultList.add(findDefectsUseCase1B.predictData(userId, predictionCode));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<Integer> predictDefectCountRate(int userId, String predictionCode) {
		List<Integer> resultList = new ArrayList<Integer>();
		try {
			resultList.add(findDefectsUseCase1C.predictData(userId, predictionCode));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	public List<Integer> getAllPredictionResultUseCase1D(String predictionId, String userId, int algorithmId) {
		predictionId = "Functional";
		List<Integer> predictedResultList = new ArrayList<Integer>();

		int predictedResult1 = Java2PythonExecutor.getPredictionResult(
				ScikitConstants.UC1D_SCIKIT_LINEAR_REGRESSION_SCRIPT_TELEPHONICA, predictionId, userId);

		int predictedResult2 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1D_SCIKIT_SVR_LINEAR_SCRIPT_TELEPHONICA, predictionId, userId);

		int predictedResult3 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1D_SCIKIT_SVR_RBF_SCRIPT_TELEPHONICA, predictionId, userId);
		predictedResultList.add(0, predictedResult1);
		predictedResultList.add(1, predictedResult2);
		predictedResultList.add(2, predictedResult3);
		return predictedResultList;
	}

	public List<Integer> getAllPredictionResultTelephonicaUseCase1(String predictionId, String userId,
			int algorithmId) {

		List<Integer> predictedResultList = new ArrayList<Integer>();

		int predictedResult1 = Java2PythonExecutor.getPredictionResult(
				ScikitConstants.UC1_TELEPHONICA_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);

		int predictedResult2 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1_TELEPHONICA_SCIKIT_SVR_LINEAR_SCRIPT, predictionId, userId);

		int predictedResult3 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1_TELEPHONICA_SCIKIT_SVR_RBF_SCRIPT, predictionId, userId);
		predictedResultList.add(0, predictedResult1);
		predictedResultList.add(1, predictedResult2);
		predictedResultList.add(2, predictedResult3);
		return predictedResultList;
	}

	public List<Integer> getAllPredictionResultUseCase1C(String predictionId, String userId, int algorithmId) {

		List<Integer> predictedResultList = new ArrayList<Integer>();

		int predictedResult1 = Java2PythonExecutor.getPredictionResult(
				ScikitConstants.UC1C_TELEPHONICA_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);

		int predictedResult2 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1C_TELEPHONICA_SCIKIT_SVR_LINEAR_SCRIPT, predictionId, userId);

		int predictedResult3 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1C_TELEPHONICA_SCIKIT_SVR_RBF_SCRIPT, predictionId, userId);
		predictedResultList.add(0, predictedResult1);
		predictedResultList.add(1, predictedResult2);
		predictedResultList.add(2, predictedResult3);
		return predictedResultList;
	}

	public List<Integer> getAllPredictionResultUseCase1B(String predictionId, String userId, int algorithmId) {

		List<Integer> predictedResultList = new ArrayList<Integer>();

		int predictedResult1 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1B_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);

		int predictedResult2 = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1B_SCIKIT_SVR_LINEAR_SCRIPT,
				predictionId, userId);
		int predictedResult3 = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1B_SCIKIT_SVR_RBF_SCRIPT,
				predictionId, userId);
		predictedResultList.add(0, predictedResult1);
		predictedResultList.add(1, predictedResult2);
		predictedResultList.add(2, predictedResult3);
		return predictedResultList;
	}

	public List<Integer> getAllPredictionResultUseCase1A(String predictionId, String userId, int algorithmId) {

		List<Integer> predictedResultList = new ArrayList<Integer>();

		int predictedResult1 = Java2PythonExecutor
				.getPredictionResult(ScikitConstants.UC1A_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);

		int predictedResult2 = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1A_SCIKIT_SVR_LINEAR_SCRIPT,
				predictionId, userId);

		int predictedResult3 = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1A_SCIKIT_SVR_RBF_SCRIPT,
				predictionId, userId);
		predictedResultList.add(0, predictedResult1);
		predictedResultList.add(1, predictedResult2);
		predictedResultList.add(2, predictedResult3);
		return predictedResultList;
	}

	public List<Integer> getPredictionResultUseCase1A(String predictionId, String userId, int algorithmId) {
		int predictedResult = 0;
		List<Integer> predictedResultList = new ArrayList<Integer>();
		if (algorithmId == 2) {
			predictedResult = Java2PythonExecutor
					.getPredictionResult(ScikitConstants.UC1A_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);
		} else if (algorithmId == 3) {
			predictedResult = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1A_SCIKIT_SVR_LINEAR_SCRIPT,
					predictionId, userId);
		} else if (algorithmId == 4) {
			predictedResult = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1A_SCIKIT_SVR_RBF_SCRIPT,
					predictionId, userId);

		}
		predictedResultList.add(predictedResult);
		return predictedResultList;
	}

	public List<Integer> getPredictionResultUseCase1B(String predictionId, String userId, int algorithmId) {
		int predictedResult = 0;
		List<Integer> predictedResultList = new ArrayList<Integer>();
		if (algorithmId == 2) {
			predictedResult = Java2PythonExecutor
					.getPredictionResult(ScikitConstants.UC1B_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);
		} else if (algorithmId == 3) {
			predictedResult = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1B_SCIKIT_SVR_LINEAR_SCRIPT,
					predictionId, userId);
		} else if (algorithmId == 4) {
			predictedResult = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1B_SCIKIT_SVR_RBF_SCRIPT,
					predictionId, userId);

		}
		predictedResultList.add(predictedResult);
		return predictedResultList;
	}

	public List<Integer> getPredictionResultUseCase1C(String predictionId, String userId, int algorithmId) {
		int predictedResult = 0;
		List<Integer> predictedResultList = new ArrayList<Integer>();
		if (algorithmId == 2) {
			predictedResult = Java2PythonExecutor.getPredictionResult(
					ScikitConstants.UC1C_TELEPHONICA_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);
		} else if (algorithmId == 3) {
			predictedResult = Java2PythonExecutor.getPredictionResult(
					ScikitConstants.UC1C_TELEPHONICA_SCIKIT_SVR_LINEAR_SCRIPT, predictionId, userId);
		} else if (algorithmId == 4) {
			predictedResult = Java2PythonExecutor
					.getPredictionResult(ScikitConstants.UC1C_TELEPHONICA_SCIKIT_SVR_RBF_SCRIPT, predictionId, userId);

		}
		predictedResultList.add(predictedResult);
		return predictedResultList;
	}

	public List<Integer> getPredictionResultUseCase1D(String predictionId, String userId, int algorithmId) {
		int predictedResult = 0;
		predictionId = "Functional";
		List<Integer> predictedResultList = new ArrayList<Integer>();
		if (algorithmId == 2) {
			predictedResult = Java2PythonExecutor.getPredictionResult(
					ScikitConstants.UC1D_SCIKIT_LINEAR_REGRESSION_SCRIPT_TELEPHONICA, predictionId, userId);
		} else if (algorithmId == 3) {
			predictedResult = Java2PythonExecutor.getPredictionResult(
					ScikitConstants.UC1D_SCIKIT_SVR_LINEAR_SCRIPT_TELEPHONICA, predictionId, userId);
		} else if (algorithmId == 4) {
			predictedResult = Java2PythonExecutor
					.getPredictionResult(ScikitConstants.UC1D_SCIKIT_SVR_RBF_SCRIPT_TELEPHONICA, predictionId, userId);

		}
		predictedResultList.add(predictedResult);
		return predictedResultList;
	}

	public List<Integer> predictDefectCountBoA(int algorithmId) {
		int predictedResult = 0;
		List<Integer> predictedResultList = new ArrayList<Integer>();
		if (algorithmId == 2) {
			predictedResult = Java2PythonExecutor.getPredictionResultBoADefectCount(
					ScikitConstants.UC_BoA_DEFECT_COUNT_SCIKIT_LINEAR_REGRESSION_SCRIPT);
		} else if (algorithmId == 3) {
			predictedResult = Java2PythonExecutor
					.getPredictionResultBoADefectCount(ScikitConstants.UC_BoA_DEFECT_COUNT_SCIKIT_SVR_LINEAR_SCRIPT);
		} else if (algorithmId == 4) {
			predictedResult = Java2PythonExecutor
					.getPredictionResultBoADefectCount(ScikitConstants.UC_BoA_DEFECT_COUNT_SCIKIT_SVR_RBF_SCRIPT);

		}
		predictedResultList.add(predictedResult);
		return predictedResultList;
	}

	public List<Integer> getPredictionResultUseCase1(String predictionId, String userId, int algorithmId) {
		int predictedResult = 0;
		List<Integer> predictedResultList = new ArrayList<Integer>();
		if (algorithmId == 2) {
			predictedResult = Java2PythonExecutor
					.getPredictionResult(ScikitConstants.UC1_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);
		} else if (algorithmId == 3) {
			predictedResult = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1_SCIKIT_SVR_LINEAR_SCRIPT,
					predictionId, userId);
		} else if (algorithmId == 4) {
			predictedResult = Java2PythonExecutor.getPredictionResult(ScikitConstants.UC1_SCIKIT_SVR_RBF_SCRIPT,
					predictionId, userId);

		}
		predictedResultList.add(predictedResult);
		return predictedResultList;
	}

	public List<Integer> getPredictionResultTelephonicaUseCase1(String predictionId, String userId, int algorithmId) {
		int predictedResult = 0;
		List<Integer> predictedResultList = new ArrayList<Integer>();
		if (algorithmId == 2) {
			predictedResult = Java2PythonExecutor.getPredictionResult(
					ScikitConstants.UC1_TELEPHONICA_SCIKIT_LINEAR_REGRESSION_SCRIPT, predictionId, userId);
		} else if (algorithmId == 3) {
			predictedResult = Java2PythonExecutor.getPredictionResult(
					ScikitConstants.UC1_TELEPHONICA_SCIKIT_SVR_LINEAR_SCRIPT, predictionId, userId);
		} else if (algorithmId == 4) {
			predictedResult = Java2PythonExecutor
					.getPredictionResult(ScikitConstants.UC1_TELEPHONICA_SCIKIT_SVR_RBF_SCRIPT, predictionId, userId);

		}
		predictedResultList.add(predictedResult);
		return predictedResultList;
	}

	private String[] startCalcUclLcl(int weightagesId, List<Integer> defectCount) throws Exception {

		StatClient client = new StatClient(configurationUtils.getJubtusServerHostIp(), configurationUtils.getPORT(),
				CrestaQueryConstants.NAME, CrestaQueryConstants.CLIENT_TIMEOUT);

		int defectCountUcl = 0;
		int defectCountLcl = 0;
		String[] calculatedValueArray = new String[4];
		try {
			String key = null;
			switch (weightagesId) {
			case 1:
				key = "defect_density";
				break;
			case 2:
				key = "defect_leakage";
				break;
			case 3:
				key = "functional_defect_rejection";
				break;
			case 4:
				key = "defect_acceptance_count";
				break;
			case 13:
				key = "defect_deferral_count";
				break;
			case 14:
				key = "functional_defect_count";
				break;
			case 15:
				key = "defect_count";
				break;
			default:
				break;
			}

			for (Integer defectCountUcllcl : defectCount) {
				client.push(key, defectCountUcllcl);

			}

			defectCountUcl = (int) Math.round(client.moment(key, 1, 0.0) + 3.0 * client.stddev(key));

			defectCountLcl = (int) Math.round(client.moment(key, 1, 0.0) - 3.0 * client.stddev(key));
			if (defectCountLcl < 0)
				defectCountLcl = 0;
			if (defectCountUcl < 0)
				defectCountUcl = 0;

			System.out.println("UCL :" + key + " " + defectCountUcl);
			System.out.println("LCL :" + key + " " + defectCountLcl);
			calculatedValueArray[0] = String.valueOf(defectCountUcl);
			calculatedValueArray[1] = String.valueOf(defectCountLcl);

		} catch (Exception ex) {
			ex.printStackTrace();
			log.debug("Exception in StartCalcUclLcl() method");
		}

		finally {
			client.getClient().close();
		}
		return calculatedValueArray;
	}

	private String[] startCalcUclLcl1(int weightagesId, List<DefectLeakageModel> defectCount) throws Exception {

		StatClient client = new StatClient(configurationUtils.getJubtusServerHostIp(), configurationUtils.getPORT(),
				CrestaQueryConstants.NAME, CrestaQueryConstants.CLIENT_TIMEOUT);

		int defectCountUcl = 0;
		int defectCountLcl = 0;
		int defectCountSecondUcl = 0;
		int defectCountSecondLcl = 0;

		String[] calculatedValueArray = new String[4];
		try {
			String key = null;
			if (weightagesId == 2) {
				key = "defect_leakage";
			}
			for (DefectLeakageModel defectDensityBean : defectCount) {
				client.push(key, defectDensityBean.getDefectLeakage().intValue());
			}

			// This is also for severity i.e. High, Medium and Low.
			// display current result.
			if (key.equals("defect_leakage")) {
				defectCountUcl = (int) Math.round(client.moment(key, 1, 0.0) + 3.0 * client.stddev(key));

				defectCountLcl = (int) Math.round(client.moment(key, 1, 0.0) - 3.0 * client.stddev(key));
			} else {
				defectCountUcl = (int) Math.round(client.moment(key, 1, 0.0) + client.stddev(key));

				defectCountLcl = (int) Math.round(client.moment(key, 1, 0.0) - client.stddev(key));
			}

			defectCountSecondUcl = (int) Math.round(client.moment(key, 1, 0.0) + 2.0 * client.stddev(key));
			defectCountSecondLcl = (int) Math.round(client.moment(key, 1, 0.0) - 2.0 * client.stddev(key));
			if (defectCountLcl < 0)
				defectCountLcl = 0;
			if (defectCountUcl < 0)
				defectCountUcl = 0;
			if (defectCountSecondUcl < 0)
				defectCountSecondUcl = 0;
			if (defectCountSecondLcl < 0)
				defectCountSecondLcl = 0;
			System.out.println("UCL :" + key + " " + defectCountUcl);
			System.out.println("LCL :" + key + " " + defectCountLcl);
			System.out.println("Second UCL :" + key + " " + defectCountSecondUcl);
			System.out.println("Second LCL :" + key + " " + defectCountSecondLcl);
			calculatedValueArray[0] = String.valueOf(defectCountUcl);
			calculatedValueArray[1] = String.valueOf(defectCountLcl);
			calculatedValueArray[2] = String.valueOf(defectCountSecondUcl);
			calculatedValueArray[3] = String.valueOf(defectCountSecondLcl);

		} catch (Exception ex) {
			ex.printStackTrace();
			log.debug("Exception in StartCalcUclLcl1() method");
		}

		finally {
			client.getClient().close();
		}
		return calculatedValueArray;
	}

	private MetricsBean getCalculateLimit(int weightagesId, List<Integer> defectCount) {
		System.out.println("Hi");
		System.out.println(configurationUtils.getPropertiesFilePath());
		System.out.println(configurationUtils.getJubatusConfigFilePath());
		/*
		 * JubatusUtils.startJubatus(CrestaConstants.JUBASTAT,
		 * CrestaConstants.JUBASTAT_CONFIG_FILE_PATH,
		 * CrestaQueryConstants.PORT);
		 */
		jubatusUtils.startJubatus(CrestaConstants.JUBASTAT, configurationUtils.getJubatusConfigFilePath(),
				configurationUtils.getPORT());
		MetricsBean metricsBean = new MetricsBean();
		try {
			String[] finalValue = startCalcUclLcl(weightagesId, defectCount);
			int[] ucl = new int[3];
			int[] lcl = new int[3];
			ucl[0] = Integer.parseInt(finalValue[0]);
			lcl[0] = Integer.parseInt(finalValue[1]);
			metricsBean.setUcl(ucl);
			metricsBean.setLcl(lcl);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			EventLoop.defaultEventLoop().shutdown();
			EventLoop.setDefaultEventLoop(null);
		}
		return metricsBean;
	}

	private MetricsBean getCalculateLimit1(int weightagesId, List<DefectLeakageModel> defectCount) {
		/*
		 * JubatusUtils.startJubatus(CrestaConstants.JUBASTAT,
		 * CrestaConstants.JUBASTAT_CONFIG_FILE_PATH,
		 * CrestaQueryConstants.PORT);
		 */

		jubatusUtils.startJubatus(CrestaConstants.JUBASTAT, configurationUtils.getJubatusConfigFilePath(),
				configurationUtils.getPORT());

		MetricsBean metricsBean = new MetricsBean();
		try {
			String[] finalValue = startCalcUclLcl1(weightagesId, defectCount);
			int[] ucl = new int[3];
			int[] lcl = new int[3];
			ucl[0] = Integer.parseInt(finalValue[0]);
			ucl[1] = Integer.parseInt(finalValue[2]);
			lcl[0] = Integer.parseInt(finalValue[1]);
			lcl[1] = Integer.parseInt(finalValue[3]);
			metricsBean.setUcl(ucl);
			metricsBean.setLcl(lcl);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			EventLoop.defaultEventLoop().shutdown();
			EventLoop.setDefaultEventLoop(null);
		}
		return metricsBean;
	}

}