package com.nttdata.web.usecase2TC.service;

import java.io.File;
import java.util.List;

import com.nttdata.web.usecase2TC.model.TestCaseOptimizationBean;

public interface TestCaseOptimizationService {

	void getOptimizationResult(File filename);
	
	public boolean checkFileExtension(String fileName);
	
}
