package com.nttdata.web.model;

public class AlgorithmBean {
	
	private int algorithmId;
	private String algorithmCode;
	public int getAlgorithmId() {
		return algorithmId;
	}
	public void setAlgorithmId(int algorithmId) {
		this.algorithmId = algorithmId;
	}
	public String getAlgorithmCode() {
		return algorithmCode;
	}
	public void setAlgorithmCode(String algorithmCode) {
		this.algorithmCode = algorithmCode;
	}
	

}
