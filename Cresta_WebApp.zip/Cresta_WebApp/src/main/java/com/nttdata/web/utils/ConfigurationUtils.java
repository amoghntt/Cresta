/*
 * Copyright 2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * Licensed under the Amazon Software License (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 * http://aws.amazon.com/asl/
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

package com.nttdata.web.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Provides configuration related utilities
 */
@Component
public class ConfigurationUtils {
	// "D:/All_Projects/CRESTA/CRESTA_UAT/opt/resources1/train_data.csv"
	@Value("${historical_data_file_path}")
	private String HISTORICAL_DATA_FILE_PATH;

	// "D:/All_Projects/CRESTA/CRESTA_UAT/opt/resources1/test_data.csv"
	@Value("${recent_data_file_path}")
	private String RECENT_DATA_FILE_PATH;

	// "D:/All_Projects/CRESTA/CRESTA_UAT/opt/resources1"
	@Value("${test_file}")
	private String TEST_FILE;
	
	
	@Value("${result_file}")
	private String RESULT_FILE;

	// "D:/All_Projects/CRESTA/CRESTA_UAT/opt/resources1/config.properties"
	@Value("${properties_file_path}")
	private String PROPERTIES_FILE_PATH;

	// "source /opt/tomcat/webapps/resources1/profile; "
	@Value("${jubatus_server_environment_file}")
	private String JUBATUS_SERVER_ENVIRONMENT_FILE;

	// "/opt/tomcat/webapps/resources1/stat/stat.json"
	@Value("${jubastat_config_file_path}")
	private String JUBASTAT_CONFIG_FILE_PATH;

	// "/opt/tomcat/webapps/resources1/regression/config.json";
	@Value("${jubaregression_config_file_path}")
	private String JUBAREGRESSION_CONFIG_FILE_PATH;

	// JSCH constants for starting Jubatus server remotely
	@Value("${jubatus_server_os_username}")
	private String JUBATUS_SERVER_OS_USERNAME;

	@Value("${jubatus_server_os_password}")
	private String JUBATUS_SERVER_OS_PASSWORD;

	@Value("${jubatus_server_host_ip}")
	private String JUBATUS_SERVER_HOST_IP;

	@Value("${jubatus_server_jsch_port}")
	private String JUBATUS_SERVER_JSCH_PORT;

	// Other constants

	@Value("${port}")
	private String PORT;

	@Value("${pred_port_dd}")
	private String PRED_PORT_DD;

	@Value("${pred_port_df}")
	private String PRED_PORT_DF;

	@Value("${pred_port_ad}")
	private String PRED_PORT_AD;

	@Value("${pred_port_fd}")
	private String PRED_PORT_FD;

	@Value("${pred_port_dr}")
	private String PRED_PORT_DR;

	@Value("${pred_port_dl}")
	private String PRED_PORT_DL;

	@Value("${pred_port_da}")
	private String PRED_PORT_DA;

	// Property Getters
	public String getHistoricalDataFilePath() {
		return HISTORICAL_DATA_FILE_PATH;
	}

	public String getRecentDataFilePath() {
		return RECENT_DATA_FILE_PATH;
	}

	public String getTEST_FILE() {
		return TEST_FILE;
	}
	
	
	public String getResult_FILE() {
		// TODO Auto-generated method stub
		return RESULT_FILE;
	}

	public String getPropertiesFilePath() {
		return PROPERTIES_FILE_PATH;
	}

	public String getJubatusServerEnvironmentFile() {
		return JUBATUS_SERVER_ENVIRONMENT_FILE;
	}

	public String getJubatusConfigFilePath() {
		return JUBASTAT_CONFIG_FILE_PATH;
	}

	public String getJubaRegressionConfigFilePath() {
		return JUBAREGRESSION_CONFIG_FILE_PATH;
	}

	public String getJubtusServerUserName() {
		return JUBATUS_SERVER_OS_USERNAME;
	}

	public String getJubtusServerPassword() {
		return JUBATUS_SERVER_OS_PASSWORD;
	}

	public String getJubtusServerHostIp() {
		return JUBATUS_SERVER_HOST_IP;
	}

	public int getJubtusServerJschPort() {
		return Integer.parseInt(JUBATUS_SERVER_JSCH_PORT);
	}

	public int getPORT() {
		return Integer.parseInt(PORT);
	}

	public int getPRED_PORT_DD() {
		return Integer.parseInt(PRED_PORT_DD);
	}

	public int getPRED_PORT_DF() {
		return Integer.parseInt(PRED_PORT_DF);
	}

	public int getPRED_PORT_AD() {
		return Integer.parseInt(PRED_PORT_AD);
	}

	public int getPRED_PORT_FD() {
		return Integer.parseInt(PRED_PORT_FD);
	}

	public int getPRED_PORT_DR() {
		return Integer.parseInt(PRED_PORT_DR);
	}

	public int getPRED_PORT_DL() {
		return Integer.parseInt(PRED_PORT_DL);
	}

	public int getPRED_PORT_DA() {
		return Integer.parseInt(PRED_PORT_DA);
	}

	

}
