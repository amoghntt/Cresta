package com.nttdata.web.model;

import java.util.List;

public class Labels {
	
	private List<String> labels;
	

	public Labels(List<String> labels) {
		super();
		this.labels = labels;
	}

	public List<String> getLabels() {
		return labels;
	}

	public void setLabels(List<String> labels) {
		this.labels = labels;
	}
	
	
	

}
