package com.nttdata.web.usecase2TC.service;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.pythonexecutor.Java2PythonExecutor;
import com.nttdata.pythonexecutor.ScikitConstants;
import com.nttdata.web.usecase2TC.model.TestCaseOptimizationBean;
import com.nttdata.web.usecase3A.service.TestCaseCoverageServiceImpl;
import com.nttdata.web.utils.ConfigurationUtils;

@Service
public class TestCaseOptimizationServiceImpl implements TestCaseOptimizationService {
	@Autowired
	ConfigurationUtils configurationUtils;
	private static Logger log = LoggerFactory.getLogger(TestCaseCoverageServiceImpl.class);

	@Override
	public void getOptimizationResult(File filename) {
		String file = filename.toString();
		List<ArrayList<Double>> resultList = Java2PythonExecutor
				.getTestOptimization(ScikitConstants.UC2_TEST_CASE_OPTIMIZATION_SCRIPT ,file);
//		log.info("resultList = " + resultList);

		List<TestCaseOptimizationBean> testOptimizationBeanList = null;
		

		/*if (resultList != null) {
			int testId = 1;
			DecimalFormat df = new DecimalFormat("#.00");
			Double percentageResult = 0.0;
			testOptimizationBeanList = new ArrayList<TestCaseOptimizationBean>();

			for (ArrayList<Double> element : resultList) {
				TestCaseOptimizationBean testOptimizationBean = new TestCaseOptimizationBean();
				testOptimizationBean.setTestCaseId("TC" + testId);
				List<Double> testSimilarityList = new ArrayList<Double>();

				for (Double element1 : element) {
					percentageResult = Double.parseDouble(df.format(element1 * 100));
					testSimilarityList.add(percentageResult);
				}

				testOptimizationBean.setTestCaseSimilarity(testSimilarityList);
				testOptimizationBeanList.add(testOptimizationBean);
				testId = testId + 1;
			}

		}*/

//		return testOptimizationBeanList;
	}

	@Override
	public boolean checkFileExtension(String fileName) {
		String extension = FilenameUtils.getExtension(fileName);
		if (extension.equalsIgnoreCase("xls") || extension.equalsIgnoreCase("xlsx")
				|| extension.equalsIgnoreCase("xlsm")) {
			return true;
		}
		return false;
	}
}
