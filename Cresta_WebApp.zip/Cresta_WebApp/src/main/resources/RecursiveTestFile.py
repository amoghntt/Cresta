import pandas as pd
import xlsxwriter
import os, sys
import glob
import ntpath
import uc2_test_case_optimization, testcaseread_post

tc=[]

pathresults='C:/Users/109182/Desktop/New folder/results/'


path= "C:/Users/109182/Desktop/New folder/testfiles"

filename = sys.argv[1]
       
print filename
test_ref=testcaseread_post.readTestCasesFromExcelFile(filename)
corpora = 'english'
test_result=uc2_test_case_optimization.optimize(corpora,filename)
#test.append(test_result)
print test_result
test_case=[]
test_results=[]
actual=[]*len(test_result)
i=1
for x in test_result:
    tc.append("TC"+str(i))
    actual.append("TC"+str(i))
    for y in x:
        actual.append(y)
    i=i+1
    test_results.append(actual)
    actual=[]
print(tc)
        #print test_results
        #print test_result
filename=str(ntpath.basename(filename))
filenameparts = filename.split('.')
        
print(filenameparts[0])
with open('C:/Users/109182/Desktop/New folder/results/'+filenameparts[0]+'Result.csv', 'w') as csv:
    csv.write('')
    csv.write(',')
    for tc1 in tc:
                csv.write(str(tc1))
                csv.write(',')
    csv.write('\n')
    i=1
    for col in test_result:
                csv.write('TC'+str(i))
                csv.write(',')
                for row in col:
                    csv.write(str(row))
                    csv.write(',')
                csv.write('\n')
                i=i+1
csv.close()
with open('C:/Users/109182/Desktop/New folder/textrequirementprocessedpost.txt','r') as p:
    lines=p.readlines()
    for line in lines:
        #print line
        test_case.append(str(line))
with open('C:/Users/109182/Desktop/New folder/textrequirementprocessedpost.txt','r') as p:
    p.close()
with open('C:/Users/109182/Desktop/New folder/results/'+filenameparts[0]+'ResultDuplicate.csv', 'w') as csv:
    csv.write('Duplicate TC Pair')
    csv.write(',')
    csv.write('\n')
    i=1
    j=1
    for row in test_result:
        j=1
        for col in row:
            if(col>=90 and j>1 and col<=100):
                if(i!=j):
                    #tc_pair= str(i)+','+str(j)
                    csv.write(str(test_ref[i-1]))
                    csv.write(',')
                    csv.write(str(i))
                    csv.write(',')
                    csv.write(str(j))
                    csv.write(',')
                    csv.write(str(test_ref[j-1]))
                    csv.write('\n')
                    csv.write(str(test_case[i-1]))
                    #csv.write('\n')
                    csv.write(str(test_case[j-1]))
                        
                    csv.write('\n')
            j=j+1
        i=i+1
csv.close()
with open('C:/Users/109182/Desktop/New folder/results/'+filenameparts[0]+'ResultRedun.csv', 'w') as csv:
    csv.write('Redundant TC Pair')
    csv.write(',')
    csv.write('\n')
    i=1
    j=1
    #k=0
    for row in test_result:
        j=1
        for col in row:
            if(col>75 and col<90 and j>1):
                #tc_pair= str(i)+','+str(j)
                #csv.write(tc_pair)
                #csv.write(str(i),str(j))
                csv.write(str(test_ref[i-1]))
                csv.write(',')
                csv.write(str(i))
                csv.write(',')
                csv.write(str(j))
                csv.write(',')
                csv.write(str(test_ref[j-1]))
                csv.write('\n')
                csv.write(str(test_case[i-1]))
                csv.write(str(test_case[j-1]))
                csv.write('\n')
            j=j+1
        i=i+1
csv.close()
resultArraytoList = test_results.tolist()
print (json.dumps(resultArraytoList))