import io
import string
import testcaseread
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import common_utils

textRequirement = common_utils.getTextRequirement()

textReqProcess = common_utils.getTextReqProcessedFilePath()

def readRequirementFromTextFile():
	"This function read requirement from text file and preprocesses it"
	with open(textRequirement, 'r') as myfile:
		data=myfile.read().replace('\n', '')   
   
	preprocessed_sentence = testcaseread.preProcessString(data.translate(None, string.punctuation))
   
	text_file = open(textReqProcess, "w")
	text_file.write(preprocessed_sentence+"\n")
	text_file.flush()
	text_file.close()
 
