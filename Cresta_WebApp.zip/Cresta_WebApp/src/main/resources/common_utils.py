import mysql.connector    


def getConnection():
    cnx = mysql.connector.connect(user='cresta', password='cresta',
                                  host='10.248.3.91',
                               database='cresta_uat')
    return cnx;

def getTextReqProcessedFilePath():
    return 'C:/Users/109182/Desktop/New folder/textrequirementprocessed.txt';

def getTextRequirement():
    return 'C:/Users/109182/Desktop/New folder/textrequirement.txt';

def getResultFilePath():
    return 'C:/Users/109182/Desktop/New folder/result.txt';


def getTestCaseXlsm():
    return '/opt/apache-tomcat-8.0.36/webapps/resources1/test-case.xlsm';
