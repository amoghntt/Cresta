import json
import sys

import mysql.connector
from pandas import DataFrame
from sklearn.svm import SVR
import numpy as numpy
import common_utils
import math

def predict_ucllcl(mydata):
   data_set=mydata
   avg=0
   num=0
   i=len(data_set)
   #average = reduce(lambda x, y: x + y, data_set) / len(data_set)
   average=numpy.mean(data_set, axis=0)
   #average=avg/num
   s = [x-average for x in data_set]
   square = [x*x for x in s]
   avg_new=0
   data=[]
   res=[]
   for x in square:
      avg_new=x+avg_new
   varience=avg_new/i
   #sigma=(varience)^(1/2)
   sigma=math.pow(varience, 0.5)
   three_sigma=3*sigma
  # print(three_sigma)
   ucl=average+three_sigma
   lcl=average-three_sigma
   #print(ucl)
   ucl=round(ucl,0)
   if lcl<0:
      lcl=0
   else:
      lcl=round(lcl)
      
   res.append(int(round(ucl,0)))
   res.append(int(round(lcl,0)))
   print(json.dumps(res))
   #return res



cnx = common_utils.getConnection()
try:
    cursor = cnx.cursor()
    cols = ['DEFECT_COUNT']
    strColumns = ','.join(cols)
    #query = "select " + strColumns + " from usecase1CTelephonica"
    query = "select " + strColumns + " from usecase1CTelephonica"
    cursor.execute(query)
    data = DataFrame(cursor.fetchall(), columns=cols)
    input_data = data[cols[:-1]][-1:]
    data = data[:-1]
finally:
    cnx.close()

X = data[cols[:-1]]
y = data.DEFECT_COUNT

predict_ucllcl(y)