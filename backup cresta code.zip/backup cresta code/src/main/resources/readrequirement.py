import io
import string

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

import common_utils
import testcaseread


textRequirement = common_utils.getTextRequirement()

textReqProcess = common_utils.getTextReqProcessedFilePath()


def readRequirementFromTextFile():
    "This function read requirement from text file and preprocesses it"
    with open(textRequirement, 'r') as myfile:
        data = myfile.read().replace('\n', '')

    # make translator object
    translator = str.maketrans('', '', string.punctuation)

    preprocessed_sentence = testcaseread.preProcessString(
        data.translate(translator))

    text_file = open(textReqProcess, "w")
    text_file.write(preprocessed_sentence + "\n")
    text_file.flush()
    text_file.close()
