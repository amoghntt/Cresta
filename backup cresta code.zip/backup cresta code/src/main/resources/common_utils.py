import mysql.connector    


def getConnection():
#     cnx = mysql.connector.connect(user='cresta', password='cresta',
#                                   host='10.248.3.91',
#                                database='cresta_uat')
    cnx = mysql.connector.connect(user='ag7434', password='Global1234',
                                  host='127.0.0.1',
                               database='cresta')
    return cnx;

def getTextReqProcessedFilePath():
    return 'F:/Cresta/textrequirementprocessed.txt';

def getTextRequirement():
    return 'F:/Cresta/textrequirement.txt';

def getResultFilePath():
    return 'F:/Cresta/result.txt';


def getTestCaseXlsm():
    return 'F:/Cresta/test-case.xlsm';
