package com.nttdata.web.usecase1B.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.nttdata.web.model.ReleaseDetails;
import com.nttdata.web.service.ETL;
import com.nttdata.web.usecase1B.dao.DefectDefferalDAO;
import com.nttdata.web.usecase1B.model.DefectDeferralModel;
import com.nttdata.web.usecase1B.model.DefectDeferralModelTelephonica;

@Service
public class DefectDefferalServiceImpl implements DefectDefferalService {

	@Autowired
	@Qualifier("scriptellaETL")
	// @Qualifier("talendETL")
	ETL etlBean;

	@Autowired
	private DefectDefferalDAO defectDefferalDAO;

	@Override
	public int[][][] processTask(String useCaseType, String predictionId, String metricsId, String userId,
			int redmineProjectId, int[] ucl, int[] lcl, int algorithmId) {
		List<Integer> oldList = new ArrayList<Integer>();

		oldList = etlBean.interactETL(useCaseType, predictionId, metricsId, userId, redmineProjectId, algorithmId);
		// List<DefectDeferralModel> resultList =
		// defectDefferalDAO.getDefectDefferalAndReleaseData(userId,
		// predictionId);
		List<DefectDeferralModelTelephonica> resultList = defectDefferalDAO
				.getDefectDefferalAndReleaseTelephonicaData(userId, predictionId);

//		List<ReleaseDetails> lastTenPredictedValues = defectDefferalDAO.getLastTenPredictions(algorithmId);

		/*int[][][] graphData = createDataSetsTelephonica(resultList, oldList, ucl, lcl, algorithmId,
				lastTenPredictedValues);*/
		int[][][] graphData = createDataSetsTelephonica(resultList, oldList, ucl, lcl, algorithmId);

		return graphData;
	}

	private int[][][] createDataSets(List<DefectDeferralModel> defectDeferralList, List<Integer> oldList, int[] ucl,
			int[] lcl, int algorithmId) {

		int maxSize = defectDeferralList.size();
		int[][] defectDeferral = new int[maxSize][];
		int[][] predictedArrayLinearRegression = new int[2][];
		int[][] uclValues = new int[maxSize][];
		int[][] lclValues = new int[maxSize][];
		int i = 0;
		for (DefectDeferralModel defect : defectDeferralList) {

			defectDeferral[i] = new int[] { defect.getReleaseVersion(), defect.getDefectDeferralCount() };
			uclValues[i] = new int[] { defect.getReleaseVersion(), ucl[0] };
			lclValues[i] = new int[] { defect.getReleaseVersion(), lcl[0] };
			i++;
		}

		uclValues[defectDeferralList.size()] = new int[] {
				defectDeferralList.get(defectDeferralList.size() - 1).getReleaseVersion() + 1, ucl[0] };
		lclValues[defectDeferralList.size()] = new int[] {
				defectDeferralList.get(defectDeferralList.size() - 1).getReleaseVersion() + 1, lcl[0] };
		predictedArrayLinearRegression[0] = defectDeferral[defectDeferral.length - 1];
		predictedArrayLinearRegression[1] = new int[] {
				defectDeferralList.get(defectDeferralList.size() - 1).getReleaseVersion(), oldList.get(0) };
		System.out.println(defectDeferral);
		if (algorithmId == 1) {
			int[][] predictedArraySVRLinearKernel = new int[2][];
			predictedArraySVRLinearKernel[0] = defectDeferral[defectDeferral.length - 1];
			predictedArraySVRLinearKernel[1] = new int[] {
					defectDeferralList.get(defectDeferralList.size() - 1).getReleaseVersion(), oldList.get(1) };

			int[][] predictedArraySVRRBFKernel = new int[2][];
			predictedArraySVRRBFKernel[0] = defectDeferral[defectDeferral.length - 1];
			predictedArraySVRRBFKernel[1] = new int[] {
					defectDeferralList.get(defectDeferralList.size() - 1).getReleaseVersion(), oldList.get(2) };

			int graphData[][][] = new int[6][][];
			graphData[0] = lclValues;
			graphData[1] = uclValues;
			graphData[2] = defectDeferral;
			graphData[3] = predictedArrayLinearRegression;
			graphData[4] = predictedArraySVRLinearKernel;
			graphData[5] = predictedArraySVRRBFKernel;
			return graphData;
		} else {

			int graphData[][][] = new int[4][][];
			graphData[0] = lclValues;
			graphData[1] = uclValues;
			graphData[2] = defectDeferral;
			graphData[3] = predictedArrayLinearRegression;
			return graphData;

		}

	}

	private int[][][] createDataSetsTelephonica(List<DefectDeferralModelTelephonica> defectDeferralModelListTelephonica,
			List<Integer> oldList, int[] ucl, int[] lcl, int algorithmId) {

		int maxSize = defectDeferralModelListTelephonica.size();
		int length = 0;
		/*int[][] uclValues = new int[maxSize][];
		int[][] lclValues = new int[maxSize][];*/
		
		int[][] uclValues ;//= new int[maxSize][];
		int[][] lclValues ;//= new int[maxSize][];
		int[][] defectDensity;
		int[][] predictedArrayLinearRegression = new int[2][];
		int[][] predictedArraySVRLinearKernel = new int[2][];
		int[][] predictedArraySVRRBFKernel = new int[2][];
		
		if(defectDeferralModelListTelephonica.get(maxSize-1).getDefectDeferralCount()==0){
			length = defectDeferralModelListTelephonica.size() - 1;
//			defectDeferralModelListTelephonica.remove(maxSize-1);
			uclValues = new int[maxSize][];
			lclValues = new int[maxSize][];
			defectDensity = new int[maxSize-1][];
			for (int i = 0; i < length; i++) {
				defectDensity[i] = new int[] { defectDeferralModelListTelephonica.get(i).getRel_Id(), defectDeferralModelListTelephonica.get(i).getDefectDeferralCount() };
				uclValues[i] = new int[] { defectDeferralModelListTelephonica.get(i).getRel_Id(), ucl[0] };
				lclValues[i] = new int[] { defectDeferralModelListTelephonica.get(i).getRel_Id(), lcl[0] };
//				i++;
			}
			uclValues[length] = new int[] {
					defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 2).getRel_Id() + 1,
					ucl[0] };
			lclValues[length] = new int[] {
					defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 2).getRel_Id() + 1,
					lcl[0] };
			predictedArrayLinearRegression[0] = defectDensity[defectDensity.length - 1];
			predictedArrayLinearRegression[1] = new int[] {
					defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 1).getRel_Id(),
					oldList.get(0) };
			
			if (algorithmId == 1) {
				predictedArraySVRLinearKernel[0] = defectDensity[defectDensity.length - 1];
				
				predictedArraySVRLinearKernel[1] = new int[] {
						defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 1).getRel_Id(),
						oldList.get(1) };

				
				predictedArraySVRRBFKernel[0] = defectDensity[defectDensity.length - 1];
				
				predictedArraySVRRBFKernel[1] = new int[] {
						defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 1).getRel_Id(),
						oldList.get(2) };
				}
			
			
		}else{
			length = defectDeferralModelListTelephonica.size();
			uclValues = new int[maxSize][];
			lclValues = new int[maxSize][];
			defectDensity = new int[maxSize][];
			for (int i = 0; i < maxSize; i++) {
				defectDensity[i] = new int[] { defectDeferralModelListTelephonica.get(i).getRel_Id(), defectDeferralModelListTelephonica.get(i).getDefectDeferralCount() };
				uclValues[i] = new int[] { defectDeferralModelListTelephonica.get(i).getRel_Id(), ucl[0] };
				lclValues[i] = new int[] { defectDeferralModelListTelephonica.get(i).getRel_Id(), lcl[0] };
//				i++;
			}
			uclValues[maxSize - 2] = new int[] {
					defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 2).getRel_Id() + 1,
					ucl[0] };
			lclValues[maxSize - 2] = new int[] {
					defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 2).getRel_Id() + 1,
					lcl[0] };
			predictedArrayLinearRegression[0] = defectDensity[defectDensity.length - 2];
			predictedArrayLinearRegression[1] = new int[] {
					defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 1).getRel_Id(),
					oldList.get(0) };
			
			if (algorithmId == 1) {
				predictedArraySVRLinearKernel[0] = defectDensity[defectDensity.length - 2];
				
				predictedArraySVRLinearKernel[1] = new int[] {
						defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 1).getRel_Id(),
						oldList.get(1) };

				
				predictedArraySVRRBFKernel[0] = defectDensity[defectDensity.length - 2];
				
				predictedArraySVRRBFKernel[1] = new int[] {
						defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 1).getRel_Id(),
						oldList.get(2) };
				}
			
		}
		
		int[][] actualDefectDensityValue = new int[1][];
		actualDefectDensityValue[0] = new int[] {
				defectDeferralModelListTelephonica.get(defectDeferralModelListTelephonica.size() - 1).getDefectDeferralCount(),
				0};

		if (algorithmId == 1) {
			
			int graphData[][][] = new int[7][][];
			graphData[0] = lclValues;
			graphData[1] = uclValues;
			graphData[2] = defectDensity;
			graphData[3] = predictedArrayLinearRegression;
//			graphData[4] = predictedArraySVRLinearKernel;
			graphData[4] = predictedArraySVRLinearKernel;
			graphData[5] = predictedArraySVRRBFKernel;
			graphData[6] = actualDefectDensityValue;
			
			return graphData;
		} else {

			int graphData[][][] = new int[5][][];
			graphData[0] = lclValues;
			graphData[1] = uclValues;
			graphData[2] = defectDensity;
			graphData[3] = predictedArrayLinearRegression;
			//graphData[3] = lastTenPredictedArray;
			graphData[4] = actualDefectDensityValue;
			return graphData;
		}

	}
}
