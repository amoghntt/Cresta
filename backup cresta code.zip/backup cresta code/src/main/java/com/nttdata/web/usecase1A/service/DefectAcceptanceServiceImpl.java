package com.nttdata.web.usecase1A.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.nttdata.web.model.ReleaseDetails;
import com.nttdata.web.service.ETL;
import com.nttdata.web.usecase1A.dao.DefectAcceptanceDAO;
import com.nttdata.web.usecase1A.model.DefectAcceptanceModelTelephonica;

@Service
public class DefectAcceptanceServiceImpl implements DefectAcceptanceService {

	@Autowired
	@Qualifier("scriptellaETL")
	ETL etlBean;

	@Autowired
	private DefectAcceptanceDAO defectAcceptanceDAO;

	@Override
	public int[][][] processTask(String useCaseType, String predictionId, String metricsId, String userId,
			int redmineProjectId, int[] ucl, int[] lcl, int algorithmId) {
		List<Integer> oldList = new ArrayList<Integer>();

		oldList = etlBean.interactETL(useCaseType, predictionId, metricsId, userId, redmineProjectId, algorithmId);
		List<DefectAcceptanceModelTelephonica> resultList = defectAcceptanceDAO
				.getDefectAcceptanceAndReleaseDataTelephonica(userId);

		int[][][] graphData = createDataSetsTelephonica(resultList, oldList, ucl, lcl, algorithmId);
		
		return graphData;
	}

	private int[][][] createDataSetsTelephonica(
			List<DefectAcceptanceModelTelephonica> defectAcceptanceModelListTelephonica, List<Integer> oldList,
			int[] ucl, int[] lcl, int algorithmId) {

		int maxSize = defectAcceptanceModelListTelephonica.size();
		int length = 0;
				
		int[][] uclValues ;
		int[][] lclValues ;
		int[][] defectDensity;
		int[][] predictedArrayLinearRegression = new int[2][];
		int[][] predictedArraySVRLinearKernel = new int[2][];
		int[][] predictedArraySVRRBFKernel = new int[2][];
		
		if(defectAcceptanceModelListTelephonica.get(maxSize-1).getDefectAcceptance()==0){
			length = defectAcceptanceModelListTelephonica.size() - 1;
//			defectAcceptanceModelListTelephonica.remove(maxSize-1);
			uclValues = new int[maxSize][];
			lclValues = new int[maxSize][];
			defectDensity = new int[maxSize-1][];
			for (int i = 0; i < length; i++) {
				defectDensity[i] = new int[] { defectAcceptanceModelListTelephonica.get(i).getRelease(), defectAcceptanceModelListTelephonica.get(i).getDefectAcceptance() };
				uclValues[i] = new int[] { defectAcceptanceModelListTelephonica.get(i).getRelease(), ucl[0] };
				lclValues[i] = new int[] { defectAcceptanceModelListTelephonica.get(i).getRelease(), lcl[0] };
//				i++;
			}
			uclValues[length] = new int[] {
					defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 2).getRelease() + 1,
					ucl[0] };
			lclValues[length] = new int[] {
					defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 2).getRelease() + 1,
					lcl[0] };
			predictedArrayLinearRegression[0] = defectDensity[defectDensity.length - 1];
			predictedArrayLinearRegression[1] = new int[] {
					defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 1).getRelease(),
					oldList.get(0) };
			
			if (algorithmId == 1) {
				predictedArraySVRLinearKernel[0] = defectDensity[defectDensity.length - 1];
				
				predictedArraySVRLinearKernel[1] = new int[] {
						defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 1).getRelease(),
						oldList.get(1) };

				
				predictedArraySVRRBFKernel[0] = defectDensity[defectDensity.length - 1];
				
				predictedArraySVRRBFKernel[1] = new int[] {
						defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 1).getRelease(),
						oldList.get(2) };
				}
			
		}else{
			length = defectAcceptanceModelListTelephonica.size();
			uclValues = new int[maxSize][];
			lclValues = new int[maxSize][];
			defectDensity = new int[maxSize][];
			for (int i = 0; i < maxSize; i++) {
				defectDensity[i] = new int[] { defectAcceptanceModelListTelephonica.get(i).getRelease(), defectAcceptanceModelListTelephonica.get(i).getDefectAcceptance() };
				uclValues[i] = new int[] { defectAcceptanceModelListTelephonica.get(i).getRelease(), ucl[0] };
				lclValues[i] = new int[] { defectAcceptanceModelListTelephonica.get(i).getRelease(), lcl[0] };
//				i++;
			}
			uclValues[maxSize - 2] = new int[] {
					defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 2).getRelease() + 1,
					ucl[0] };
			lclValues[maxSize - 2] = new int[] {
					defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 2).getRelease() + 1,
					lcl[0] };
			predictedArrayLinearRegression[0] = defectDensity[defectDensity.length - 2];
			predictedArrayLinearRegression[1] = new int[] {
					defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 1).getRelease(),
					oldList.get(0) };
			
			if (algorithmId == 1) {
				predictedArraySVRLinearKernel[0] = defectDensity[defectDensity.length - 2];
				
				predictedArraySVRLinearKernel[1] = new int[] {
						defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 1).getRelease(),
						oldList.get(1) };

				
				predictedArraySVRRBFKernel[0] = defectDensity[defectDensity.length - 2];
				
				predictedArraySVRRBFKernel[1] = new int[] {
						defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 1).getRelease(),
						oldList.get(2) };
				}
			
		}
		
		int[][] actualDefectDensityValue = new int[1][];
		actualDefectDensityValue[0] = new int[] {
				defectAcceptanceModelListTelephonica.get(defectAcceptanceModelListTelephonica.size() - 1).getDefectAcceptance(),
				0};

		if (algorithmId == 1) {
			
			int graphData[][][] = new int[7][][];
			graphData[0] = lclValues;
			graphData[1] = uclValues;
			graphData[2] = defectDensity;
			graphData[3] = predictedArrayLinearRegression;
//			graphData[4] = predictedArraySVRLinearKernel;
			graphData[4] = predictedArraySVRLinearKernel;
			graphData[5] = predictedArraySVRRBFKernel;
			graphData[6] = actualDefectDensityValue;
			
			return graphData;
		} else {

			int graphData[][][] = new int[5][][];
			graphData[0] = lclValues;
			graphData[1] = uclValues;
			graphData[2] = defectDensity;
			graphData[3] = predictedArrayLinearRegression;
			//graphData[3] = lastTenPredictedArray;
			graphData[4] = actualDefectDensityValue;
			return graphData;

		}

	}

}
