package com.nttdata.web.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jboss.netty.handler.codec.http.HttpRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nttdata.web.common.CommonService;
import com.nttdata.web.model.AlgorithmBean;
import com.nttdata.web.model.ConfigBean;
import com.nttdata.web.model.MetricsBean;
import com.nttdata.web.model.PredictionBean;
import com.nttdata.web.model.ProjectBean;
import com.nttdata.web.model.UserBean;
import com.nttdata.web.service.CalculateUCLLCLService;
import com.nttdata.web.service.ConfigService;

import routines.system.StringUtils;
import scriptella.driver.spring.EtlExecutorBean;
import scriptella.execution.EtlExecutorException;

@Controller
public class MetricsController {

	@Autowired
	private ConfigService configService;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private CalculateUCLLCLService calculateUCLLCLService;
	
	@Autowired
	@Resource(name = "predictDefectDensityUseCaseTelephonica")
	protected EtlExecutorBean predictDefectDensityUseCaseTelephonicaBean;
	
	@Autowired
	@Resource(name = "predictDefectAcceptanceTelephonica")
	protected EtlExecutorBean predictDefectAcceptanceTelephonicaBean;
	
	@Autowired
	@Resource(name = "predictDefectDeferralTelephonica")
	protected EtlExecutorBean predictDefectDeferralTelephonicaBean;
	
	@Autowired
	@Resource(name = "predictDefectCountTelephonica")
	protected EtlExecutorBean predictDefectCountTelephonicaBean;
	
	@Autowired
	@Resource(name = "predictFunctionalDefectCountTelephonica")
	protected EtlExecutorBean predictFunctionalDefectCountTelephonicaBean;
	
	@Autowired
	@Resource(name = "predictLeakage")
	protected EtlExecutorBean predictLeakageBean;
	
	@Autowired
	@Resource(name = "defectiveModules")
	protected EtlExecutorBean defectiveModulesBean;

	@RequestMapping(value = "/metrics", method = RequestMethod.POST)
	public ModelAndView getMetricsFromUser(@ModelAttribute("configBean") ConfigBean configBean,
			HttpServletRequest request) {
		Map<String, List<MetricsBean>> predictMetricMapping = getPredictMetricsMapping();
		
		HttpSession session = request.getSession();
		session.setAttribute("PREDICTMETRICMAPPING", predictMetricMapping);
		String predictionId = configBean.getPredictBean().getPredictionId();
		session.setAttribute("SELECTEDPROJECT", configBean.getProjectBean().getRedmineProjectId());
		PredictionBean predictBean = configBean.getPredictBean();

		Map<String, String> resultValidatePredictDataMap = configService.validatePredictData(configBean);
		session.setAttribute("SELECTEDPREDICTION", predictionId);
		session.setAttribute("SELECTEDTRENDPARAMETER", predictBean.getTrendParameterBean().getParameterId());

		Map<String, List<MetricsBean>> metricBeanList = (Map<String, List<MetricsBean>>) session
				.getAttribute("PREDICTMETRICMAPPING");
		List<MetricsBean> metricList = getMetricsListFromPredictionId(metricBeanList, predictionId);
		predictBean.setMetricsList(metricList);
		configBean.setPredictBean(predictBean);
		configBean.getProjectBean()
				.setProjectName(commonService.getProjectName(configBean.getProjectBean().getRedmineProjectId(),
						(List<ProjectBean>) session.getAttribute("PROJECTLIST")));
		configBean.getPredictBean().setPredictDescription(commonService.getPredictionName(predictionId,
				(List<PredictionBean>) session.getAttribute("PREDICTLIST")));
		configBean.setAlgorithmBeanList((List<AlgorithmBean>) session.getAttribute("ALGORITHMLIST"));
		session.setAttribute("SELECTEDPROJECTNAME", configBean.getProjectBean().getProjectName());
		
		MetricsBean mtrBean = configBean.getPredictBean().getMetricsList().get(0);
		System.out.println(mtrBean);
		
		
		
		int metricsSize = configBean.getPredictBean().getMetricsList().size();
		ModelAndView modelAndView = null;
		Integer projectId = (Integer) session.getAttribute("SELECTEDPROJECT");
		UserBean userBean = (UserBean) session.getAttribute("USERBEAN");
		Integer userId = Integer.parseInt(userBean.getUserId());
		if (predictionId.equals("DEFECT_DENSITY")) {
			
			commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionId);
			modelAndView = new ModelAndView("predictDefectDensityMetricsForUseCase1");
			etlForDefectDensity(userId.toString(), projectId.toString(), predictionId);
			
		} else if (predictionId.equals("DEFECTIVE_MODULES")) {
			
			commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionId);
			modelAndView = new ModelAndView("defectivemodulesmetrics");
			etlForDefectiveModules(userId.toString(), projectId.toString(), predictionId);
			
		} else if (predictionId.equals("DEFECT_LEAKAGE")) {
			
			commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionId);
		    modelAndView = new ModelAndView("defectleakagemetrics");
		    etlForDefectLeakage(userId.toString(), projectId.toString(), predictionId);
		    
		} else if (predictionId.equals("DEFECT_ACCEPTANCE_RATE")) {
			
			commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionId);
			modelAndView = new ModelAndView("defectacceptancemetrics");
			etlForDefectAcceptance(userId.toString(), projectId.toString(), predictionId);
			
		} else if (predictionId.equals("DEFECT_DEFERRAL_RATE")) {
			
			commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionId);
			modelAndView = new ModelAndView("defectDefferalmetrics");
			etlForDefectDeferrel(userId.toString(), projectId.toString(), predictionId);
			
		} else if (predictionId.equals("DEFECT_COUNT")) {
			
			commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionId);
			modelAndView = new ModelAndView("defectcountmetrics");
			etlForDefectCount(userId.toString(), projectId.toString(), predictionId);
			
		} else if (predictionId.equals("FUNCTIONAL_DEFECT_COUNT")) {
			
			commonService.deleteDataFromTempDensitytable(Integer.parseInt(userBean.getUserId()), predictionId);
			modelAndView = new ModelAndView("functionaldefectmetrics");
			etlForFucntionalDefects(userId.toString(), projectId.toString(), predictionId);
			
		} else if (predictionId.equals("DEFECT_COUNT1")) {
			modelAndView = new ModelAndView("defectcountboa");
		}
		
		modelAndView.addObject("configBean", configBean);
		modelAndView.addObject("algorithmList",session.getAttribute("ALGORITHMLIST"));
		modelAndView.addObject("metricsSize", metricsSize);
		modelAndView.addObject("metricBean", getUCLLCL(request, mtrBean.getMetricsId()));
		
		return modelAndView;
	}

	
	public MetricsBean getUCLLCL(HttpServletRequest request, int metricsId){
		HttpSession session = request.getSession();
		UserBean userBean = (UserBean) session.getAttribute("USERBEAN");
		Integer userId = Integer.parseInt(userBean.getUserId());
		String predictionCode = (String) session.getAttribute("SELECTEDPREDICTION");
		Integer projectId = (Integer) session.getAttribute("SELECTEDPROJECT");
		MetricsBean metricsBean = new MetricsBean();
		metricsBean = calculateUCLLCLService.getDefectCountMetricsBean(userId, predictionCode, metricsId, projectId);
		return metricsBean;
	}
	
	private List<MetricsBean> getMetricsListFromPredictionId(Map<String, List<MetricsBean>> metricBeanList,
			String predictionId) {
		for (Entry<String, List<MetricsBean>> entry : metricBeanList.entrySet()) {
			if (entry.getKey().equals(predictionId)) {
				return entry.getValue();
			}
		}
		return new ArrayList<MetricsBean>();
	}
	
	public void etlForDefectDensity(String userId, String projectId, String predictionId){
		Map<String, String> properties = new HashMap<String, String>();
		try {
			properties.put("userId", userId);
			properties.put("projectId", StringUtils.valueOf(projectId));
			properties.put("predictionCode", predictionId);

			predictDefectDensityUseCaseTelephonicaBean.setProperties(properties);
			predictDefectDensityUseCaseTelephonicaBean.setConfiguration(null);
			predictDefectDensityUseCaseTelephonicaBean.afterPropertiesSet();

			// Execute ETL script
			predictDefectDensityUseCaseTelephonicaBean.execute();

			System.out.println("executed");
		}catch (EtlExecutorException etlExecutorException) {
			etlExecutorException.printStackTrace();
		}catch (Exception e1) {
			e1.printStackTrace();
		}
	}
	
	public EtlExecutorBean getPredictDefectDensityUseCaseTelephonicaBean() {
		return predictDefectDensityUseCaseTelephonicaBean;
	}

	public void setPredictDefectDensityUseCaseTelephonicaBean(
			EtlExecutorBean predictDefectDensityUseCaseTelephonicaBean) {
		this.predictDefectDensityUseCaseTelephonicaBean = predictDefectDensityUseCaseTelephonicaBean;
	}

	public void etlForDefectAcceptance(String userId, String projectId, String predictionId){
		Map<String, String> properties = new HashMap<String, String>();
		try {
			properties.put("userId", userId);
			properties.put("projectId", StringUtils.valueOf(projectId));
			properties.put("predictionCode", predictionId);

			predictDefectAcceptanceTelephonicaBean.setProperties(properties);
			predictDefectAcceptanceTelephonicaBean.setConfiguration(null);
			predictDefectAcceptanceTelephonicaBean.afterPropertiesSet();

			predictDefectAcceptanceTelephonicaBean.execute();

			System.out.println("executed");
		}catch (EtlExecutorException etlExecutorException) {
//			log.debug("Error executing ETL file" + etlExecutorException);
			etlExecutorException.printStackTrace();
		}catch (Exception e1) {
			e1.printStackTrace();
		}

	}
	
	public EtlExecutorBean getPredictDefectAcceptanceTelephonicaBean() {
		return predictDefectAcceptanceTelephonicaBean;
	}

	public void setPredictDefectAcceptanceTelephonicaBean(EtlExecutorBean predictDefectAcceptanceTelephonicaBean) {
		this.predictDefectAcceptanceTelephonicaBean = predictDefectAcceptanceTelephonicaBean;
	}
	
	
	public void etlForDefectDeferrel(String userId, String projectId, String predictionId){
		Map<String, String> properties = new HashMap<String, String>();
		try {
			properties.put("userId", userId);
			properties.put("projectId", StringUtils.valueOf(projectId));
			properties.put("predictionCode", predictionId);

			predictDefectDeferralTelephonicaBean.setProperties(properties);
			predictDefectDeferralTelephonicaBean.setConfiguration(null);
			predictDefectDeferralTelephonicaBean.afterPropertiesSet();

			predictDefectDeferralTelephonicaBean.execute();

			System.out.println("executed");
		}catch (EtlExecutorException etlExecutorException) {
//			log.debug("Error executing ETL file" + etlExecutorException);
			etlExecutorException.printStackTrace();
		}catch (Exception e1) {
			e1.printStackTrace();
		}

	}
	
	public EtlExecutorBean getPredictDefectDeferralTelephonicaBean() {
		return predictDefectDeferralTelephonicaBean;
	}

	public void setPredictDefectDeferralTelephonicaBean(EtlExecutorBean predictDefectDeferralTelephonicaBean) {
		this.predictDefectDeferralTelephonicaBean = predictDefectDeferralTelephonicaBean;
	}
	
	
	public void etlForDefectCount(String userId, String projectId, String predictionId){
		Map<String, String> properties = new HashMap<String, String>();
		try {
			properties.put("userId", userId);
			properties.put("projectId", StringUtils.valueOf(projectId));
			properties.put("predictionCode", predictionId);

			predictDefectCountTelephonicaBean.setProperties(properties);
			predictDefectCountTelephonicaBean.setConfiguration(null);
			predictDefectCountTelephonicaBean.afterPropertiesSet();

			predictDefectCountTelephonicaBean.execute();

			System.out.println("executed");
		}catch (EtlExecutorException etlExecutorException) {
//			log.debug("Error executing ETL file" + etlExecutorException);
			etlExecutorException.printStackTrace();
		}catch (Exception e1) {
			e1.printStackTrace();
		}

	}
	
	public EtlExecutorBean getPredictDefectCountTelephonicaBean() {
		return predictDefectCountTelephonicaBean;
	}

	public void setPredictDefectCountTelephonicaBean(EtlExecutorBean predictDefectCountTelephonicaBean) {
		this.predictDefectCountTelephonicaBean = predictDefectCountTelephonicaBean;
	}
	
	
	public void etlForFucntionalDefects(String userId, String projectId, String predictionId){
		Map<String, String> properties = new HashMap<String, String>();
		try {
			
			properties.put("userId", userId);
			properties.put("projectId", StringUtils.valueOf(projectId));
			properties.put("predictionCode", predictionId);

			predictFunctionalDefectCountTelephonicaBean.setProperties(properties);
			predictFunctionalDefectCountTelephonicaBean.setConfiguration(null);
			predictFunctionalDefectCountTelephonicaBean.afterPropertiesSet();

			predictFunctionalDefectCountTelephonicaBean.execute();

			System.out.println("executed");
			
		}catch (EtlExecutorException etlExecutorException) {
//			log.debug("Error executing ETL file" + etlExecutorException);
			etlExecutorException.printStackTrace();
		}catch (Exception e1) {
			e1.printStackTrace();
		}

	}
	
	public EtlExecutorBean getPredictFunctionalDefectCountTelephonicaBean() {
		return predictFunctionalDefectCountTelephonicaBean;
	}

	public void setPredictFunctionalDefectCountTelephonicaBean(
			EtlExecutorBean predictFunctionalDefectCountTelephonicaBean) {
		this.predictFunctionalDefectCountTelephonicaBean = predictFunctionalDefectCountTelephonicaBean;
	}
	
	
	public void etlForDefectLeakage(String userId, String projectId, String predictionId){
		Map<String, String> properties = new HashMap<String, String>();
		try {
			
			properties.put("userId", userId);
			properties.put("projectId", StringUtils.valueOf(projectId));
			properties.put("predictionCode", predictionId);

			predictLeakageBean.setProperties(properties);
			predictLeakageBean.setConfiguration(null);
			predictLeakageBean.afterPropertiesSet();

			predictLeakageBean.execute();

			System.out.println("executed");
			
		}catch (EtlExecutorException etlExecutorException) {
//			log.debug("Error executing ETL file" + etlExecutorException);
			etlExecutorException.printStackTrace();
		}catch (Exception e1) {
			e1.printStackTrace();
		}

	}
	
	public void setPredictLeakageBean(EtlExecutorBean predictLeakageBean) {
		this.predictLeakageBean = predictLeakageBean;
	}
	
	public EtlExecutorBean getPredictLeakageBean() {
		return predictLeakageBean;
	}
	
	public void etlForDefectiveModules(String userId, String projectId, String predictionId){
		Map<String, String> properties = new HashMap<String, String>();
		try {
			
			properties.put("userId", userId);
			properties.put("projectId", StringUtils.valueOf(projectId));
			properties.put("predictionCode", predictionId);

			defectiveModulesBean.setProperties(properties);
			defectiveModulesBean.setConfiguration(null);
			defectiveModulesBean.afterPropertiesSet();

			defectiveModulesBean.execute();

			System.out.println("executed");
		}catch (EtlExecutorException etlExecutorException) {
//			log.debug("Error executing ETL file" + etlExecutorException);
			etlExecutorException.printStackTrace();
		}catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	
	public EtlExecutorBean getDefectiveModulesBean() {
		return defectiveModulesBean;
	}

	public void setDefectiveModulesBean(EtlExecutorBean defectiveModulesBean) {
		this.defectiveModulesBean = defectiveModulesBean;
	}
	
	
	private Map<String, List<MetricsBean>> getPredictMetricsMapping() {
		return configService.getPredictMetricsMappingService();

	}
	
}
