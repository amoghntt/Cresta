package com.nttdata.web.service;

public interface AceMasterService {

	String getPieChartData();

	String getTestEnvironmentORSoftwareData(String category);

}
