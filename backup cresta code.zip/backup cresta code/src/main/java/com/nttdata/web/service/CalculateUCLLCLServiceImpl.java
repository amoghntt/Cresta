package com.nttdata.web.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.nttdata.web.model.MetricsBean;
import com.nttdata.web.usecase3.model.DefectLeakageModel;

import routines.system.StringUtils;

@Service
public class CalculateUCLLCLServiceImpl
  implements CalculateUCLLCLService
{
  @Autowired
  @Qualifier("scriptellaETL")
  ETL etlBean;
  @Autowired
  private ConfigService configService;
  
  public CalculateUCLLCLServiceImpl() {}
  
  public MetricsBean processCalculateUclLcl(int projectId, String metricsId, List<Integer> defectCount)
  {
    return processCalculateUclLcl("calculateUclLcl", null, metricsId, null, projectId, defectCount);
  }
  
  public MetricsBean processCalculateUclLcl1(int projectId, String metricsId, List<DefectLeakageModel> defectCount)
  {
    return processCalculateUclLcl1("calculateUclLcl", null, metricsId, null, projectId, defectCount);
  }
  

  public MetricsBean processCalculateUclLcl(String useCaseType, String predictionId, String metricsId, String userId, int redmineProjectId, List<Integer> defectCount)
  {
    MetricsBean metricsBean = new MetricsBean();
    List<int[]> resultList = etlBean.interactETLForUclLcl(useCaseType, predictionId, metricsId, userId, redmineProjectId, defectCount);
    
    int[] ucl = new int[3];
    int[] lcl = new int[3];
    Integer[] array = new Integer[resultList.size()];
    



    array = (Integer[])resultList.toArray(array);
    ucl[0] = array[0].intValue();
    lcl[0] = array[1].intValue();
    metricsBean.setUcl(ucl);
    metricsBean.setLcl(lcl);
    

    return metricsBean;
  }
  

  public MetricsBean processCalculateUclLcl1(String useCaseType, String predictionId, String metricsId, String userId, int redmineProjectId, List<DefectLeakageModel> defectCount)
  {
    MetricsBean metricsBean = new MetricsBean();
    List<int[]> resultList = etlBean.interactETLForUclLcl1(useCaseType, predictionId, metricsId, userId, redmineProjectId, defectCount);
    
    metricsBean.setLcl((int[])resultList.get(0));
    metricsBean.setUcl((int[])resultList.get(1));
    return metricsBean;
  }
  

  public MetricsBean getDefectCountMetricsBean(Integer userId, String predictionCode, Integer metricsId, Integer projectId)
  {
    List<Integer> defectCount = new ArrayList();
    MetricsBean metricsBean = new MetricsBean();
    if (metricsId.intValue() == 13) {
      defectCount = configService.getDefectDeferralCountTelephonica(userId.intValue(), predictionCode);
      metricsBean = processCalculateUclLcl(projectId.intValue(), StringUtils.valueOf(metricsId), defectCount);
    } else if (metricsId.intValue() == 4) {
      defectCount = configService.getDefectAcceptanceCountTelephonica(userId.intValue(), predictionCode);
      metricsBean = processCalculateUclLcl(projectId.intValue(), StringUtils.valueOf(metricsId), defectCount);
    } else if ((metricsId.intValue() == 1) && (predictionCode.equals("DEFECT_DENSITY"))) {
      defectCount = configService.getDefectDensityCountTelephonica(userId.intValue(), predictionCode);
      metricsBean = processCalculateUclLcl(projectId.intValue(), StringUtils.valueOf(metricsId), defectCount);
    } else if (((metricsId.intValue() == 1) || (metricsId.intValue() == 2) || (metricsId.intValue() == 3)) && (predictionCode.equals("DEFECTIVE_MODULES"))) {
      defectCount = configService.getDefectModuleCount(userId.intValue(), predictionCode, metricsId);
      metricsBean = processCalculateUclLcl(projectId.intValue(), StringUtils.valueOf(metricsId), defectCount);
    } else if (metricsId.intValue() == 15) {
      defectCount = configService.getDefectCountTelephonica(userId.intValue(), predictionCode);
      metricsBean = processCalculateUclLcl(projectId.intValue(), StringUtils.valueOf(metricsId), defectCount);
    } else if (metricsId.intValue() == 14) {
      defectCount = configService.getFunctionalDefectDensityCountTelephonica(userId.intValue(), predictionCode);
      metricsBean = processCalculateUclLcl(projectId.intValue(), StringUtils.valueOf(metricsId), defectCount);
    } else if (metricsId.intValue() == 2) {
      List<DefectLeakageModel> defectDensityList = configService.getDefectLeakageData(userId.intValue(), predictionCode);
      metricsBean = processCalculateUclLcl1(projectId.intValue(), StringUtils.valueOf(metricsId), defectDensityList);
    }
    return metricsBean;
  }
}