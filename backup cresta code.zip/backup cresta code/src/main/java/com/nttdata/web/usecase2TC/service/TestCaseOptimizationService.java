package com.nttdata.web.usecase2TC.service;

import java.util.List;

import com.nttdata.web.usecase2TC.model.TestCaseOptimizationBean;

public interface TestCaseOptimizationService {

	List<TestCaseOptimizationBean> getOptimizationResult();
	
	public boolean checkFileExtension(String fileName);
	
}
