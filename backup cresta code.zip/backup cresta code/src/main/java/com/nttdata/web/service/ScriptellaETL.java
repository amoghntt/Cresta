package com.nttdata.web.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nttdata.web.controllers.LoginController;
import com.nttdata.web.dao.ConfigDAO;
import com.nttdata.web.model.PredictedModel;
import com.nttdata.web.usecase3.model.DefectLeakageModel;

import routines.system.StringUtils;
import scriptella.driver.spring.EtlExecutorBean;
import scriptella.execution.EtlExecutorException;

@Service
public class ScriptellaETL implements ETL {

	private static final Logger log = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	JubatusProcessor jubatusProcessor;

	@Autowired
	ConfigDAO configDAO;

	public EtlExecutorBean getPredictDefectDeferralTelephonicaBean() {
		return predictDefectDeferralTelephonicaBean;
	}

	public void setPredictDefectDeferralTelephonicaBean(EtlExecutorBean predictDefectDeferralTelephonicaBean) {
		this.predictDefectDeferralTelephonicaBean = predictDefectDeferralTelephonicaBean;
	}

	@Autowired
	@Resource(name = "predictLeakage")
	protected EtlExecutorBean predictLeakageBean;

	public EtlExecutorBean getDefectiveModulesBean() {
		return defectiveModulesBean;
	}

	public void setDefectiveModulesBean(EtlExecutorBean defectiveModulesBean) {
		this.defectiveModulesBean = defectiveModulesBean;
	}

	@Autowired
	@Resource(name = "defectiveModules")
	protected EtlExecutorBean defectiveModulesBean;

	@Autowired
	@Resource(name = "predictDefectDensityUseCaseTelephonica")
	protected EtlExecutorBean predictDefectDensityUseCaseTelephonicaBean;

	@Autowired
	@Resource(name = "predictDefectDeferralTelephonica")
	protected EtlExecutorBean predictDefectDeferralTelephonicaBean;

	@Autowired
	@Resource(name = "predictDefectAcceptanceTelephonica")
	protected EtlExecutorBean predictDefectAcceptanceTelephonicaBean;

	@Autowired
	@Resource(name = "predictDefectCountTelephonica")
	protected EtlExecutorBean predictDefectCountTelephonicaBean;

	@Autowired
	@Resource(name = "predictFunctionalDefectCountTelephonica")
	protected EtlExecutorBean predictFunctionalDefectCountTelephonicaBean;

	public EtlExecutorBean getPredictFunctionalDefectCountTelephonicaBean() {
		return predictFunctionalDefectCountTelephonicaBean;
	}

	public void setPredictFunctionalDefectCountTelephonicaBean(
			EtlExecutorBean predictFunctionalDefectCountTelephonicaBean) {
		this.predictFunctionalDefectCountTelephonicaBean = predictFunctionalDefectCountTelephonicaBean;
	}

	public EtlExecutorBean getPredictDefectCountTelephonicaBean() {
		return predictDefectCountTelephonicaBean;
	}

	public void setPredictDefectCountTelephonicaBean(EtlExecutorBean predictDefectCountTelephonicaBean) {
		this.predictDefectCountTelephonicaBean = predictDefectCountTelephonicaBean;
	}

	public EtlExecutorBean getPredictDefectAcceptanceTelephonicaBean() {
		return predictDefectAcceptanceTelephonicaBean;
	}

	public void setPredictDefectAcceptanceTelephonicaBean(EtlExecutorBean predictDefectAcceptanceTelephonicaBean) {
		this.predictDefectAcceptanceTelephonicaBean = predictDefectAcceptanceTelephonicaBean;
	}

	@Override
	public List<Integer> interactETL(String eTLType, String predictionId, String metricsId, String userId,
			int redmineProjectId, int algorithmId) {
		if (eTLType.equalsIgnoreCase("calculateUclLcl")) {
		} else if (eTLType.equalsIgnoreCase("predictUseCase1")) {
			return predictUseCase1(userId, String.valueOf(redmineProjectId), predictionId, algorithmId);
		} else if (eTLType.equalsIgnoreCase("predictUseCase1A")) {
			return predictUseCase1A(userId, String.valueOf(redmineProjectId), predictionId, algorithmId);
		} else if (eTLType.equalsIgnoreCase("predictUseCase3")) {
			return predictUseCase3(userId, String.valueOf(redmineProjectId), predictionId);
		} else if (eTLType.equalsIgnoreCase("predictUseCase1B")) {
			return predictUseCase1B(userId, String.valueOf(redmineProjectId), predictionId, algorithmId);
		} else if (eTLType.equalsIgnoreCase("predictUseCase1C")) {
			return predictUseCase1C(userId, String.valueOf(redmineProjectId), predictionId, algorithmId);
		} else if (eTLType.equalsIgnoreCase("predictUseCase1D")) {
			return predictUseCase1D(userId, String.valueOf(redmineProjectId), predictionId, algorithmId);
		} else if (eTLType.equalsIgnoreCase("predictDefectCountBoA")) {
			return predictDefectCountBoA(userId, String.valueOf(redmineProjectId), predictionId, algorithmId);
		}
		return null;
	}

	public List<int[]> interactETLForUclLcl(String eTLType, String predictionId, String metricsId, String userId,
			int redmineProjectId, List<Integer> defectCount) {
		if (eTLType.equalsIgnoreCase("calculateUclLcl")) {
			return retrieveUclLclData(String.valueOf(redmineProjectId), Integer.parseInt(metricsId), defectCount);
		}
		return null;
	}

	private List<int[]> retrieveUclLclData(String projectId, int metricsId, List<Integer> defectCount) {
	    Map<String, String> properties = new HashMap();
	    properties.put("projectId", StringUtils.valueOf(projectId));
	    

	    return jubatusProcessor.UclLcl_python();
	  }
	  

	public List<int[]> interactETLForUclLcl1(String eTLType, String predictionId, String metricsId, String userId,
			int redmineProjectId, List<DefectLeakageModel> defectCount) {
		if (eTLType.equalsIgnoreCase("calculateUclLcl")) {
			return retrieveUclLclData1(String.valueOf(redmineProjectId), Integer.parseInt(metricsId), defectCount);
		}
		return null;
	}

	private List<int[]> retrieveUclLclData1(String projectId, int metricsId, List<DefectLeakageModel> defectCount) {
		Map<String, String> properties = new HashMap<String, String>();
		properties.put("projectId", StringUtils.valueOf(projectId));

		return jubatusProcessor.computeUclLclData1(metricsId, defectCount);
	}

	private List<Integer> predictUseCase1A(String userId, String projectId, String predictionId, int algorithmId) {
		List<Integer> resultList = null;
		Map<String, String> properties = new HashMap<String, String>();

		try {
			/*
			 * properties.put("userId", userId); properties.put("projectId",
			 * StringUtils.valueOf(projectId)); properties.put("predictionCode",
			 * predictionId);
			 * 
			 * predictDefectAcceptanceTelephonicaBean.setProperties(properties);
			 * predictDefectAcceptanceTelephonicaBean.setConfiguration(null);
			 * predictDefectAcceptanceTelephonicaBean.afterPropertiesSet();
			 * 
			 * predictDefectAcceptanceTelephonicaBean.execute();
			 * 
			 * System.out.println("executed");
			 */

			if (algorithmId == 0) {
				resultList = jubatusProcessor.predictDensityForUseCase1A(Integer.parseInt(userId), predictionId);
			} else if (algorithmId > 1) {
				resultList = jubatusProcessor.getPredictionResultUseCase1A(predictionId, userId, algorithmId);
			} else if (algorithmId == 1) {
				resultList = jubatusProcessor.getAllPredictionResultUseCase1A(predictionId, userId, algorithmId);
			}
		} /*
			 * catch (EtlExecutorException etlExecutorException) {
			 * log.debug("Error executing ETL file" + etlExecutorException);
			 * etlExecutorException.printStackTrace(); }
			 */ catch (Exception e1) {
			e1.printStackTrace();
		}

		return resultList;

	}

	private List<Integer> predictUseCase1B(String userId, String projectId, String predictionId, int algorithmId) {
		List<Integer> resultList = null;
		Map<String, String> properties = new HashMap<String, String>();

		try {
			/*
			 * properties.put("userId", userId); properties.put("projectId",
			 * StringUtils.valueOf(projectId)); properties.put("predictionCode",
			 * predictionId);
			 * 
			 * predictDefectDeferralTelephonicaBean.setProperties(properties);
			 * predictDefectDeferralTelephonicaBean.setConfiguration(null);
			 * predictDefectDeferralTelephonicaBean.afterPropertiesSet();
			 * 
			 * predictDefectDeferralTelephonicaBean.execute();
			 * 
			 * System.out.println("executed");
			 */

			if (algorithmId == 0) {
				resultList = jubatusProcessor.predictDefectDeferralRate(Integer.parseInt(userId), predictionId);
			} else if (algorithmId > 1) {
				resultList = jubatusProcessor.getPredictionResultUseCase1B(predictionId, userId, algorithmId);
			} else if (algorithmId == 1) {
				resultList = jubatusProcessor.getAllPredictionResultUseCase1B(predictionId, userId, algorithmId);
			}
		} /*
			 * catch (EtlExecutorException etlExecutorException) {
			 * log.debug("Error executing ETL file" + etlExecutorException);
			 * etlExecutorException.printStackTrace(); }
			 */ catch (Exception e1) {
			e1.printStackTrace();
		}

		return resultList;

	}

	private List<Integer> predictUseCase3(String userId, String projectId, String predictionId) {
		List<Integer> resultList = null;
		Map<String, String> properties = new HashMap<String, String>();

		try {
			/*
			 * properties.put("userId", userId); properties.put("projectId",
			 * StringUtils.valueOf(projectId)); properties.put("predictionCode",
			 * predictionId);
			 * 
			 * predictLeakageBean.setProperties(properties);
			 * predictLeakageBean.setConfiguration(null);
			 * predictLeakageBean.afterPropertiesSet();
			 * 
			 * predictLeakageBean.execute();
			 * 
			 * System.out.println("executed");
			 */
			resultList = jubatusProcessor.predictDensityForUseCase3(Integer.parseInt(userId), predictionId);

		} /*
			 * catch (EtlExecutorException etlExecutorException) {
			 * log.debug("Error executing ETL file" + etlExecutorException);
			 * etlExecutorException.printStackTrace(); }
			 */ catch (Exception e1) {
			e1.printStackTrace();
		}

		return resultList;
	}

	private List<Integer> predictUseCase1C(String userId, String projectId, String predictionId, int algorithmId) {
		List<Integer> resultList = null;
		Map<String, String> properties = new HashMap<String, String>();

		try {
			/*
			 * properties.put("userId", userId); properties.put("projectId",
			 * StringUtils.valueOf(projectId)); properties.put("predictionCode",
			 * predictionId);
			 * 
			 * predictDefectCountTelephonicaBean.setProperties(properties);
			 * predictDefectCountTelephonicaBean.setConfiguration(null);
			 * predictDefectCountTelephonicaBean.afterPropertiesSet();
			 * 
			 * predictDefectCountTelephonicaBean.execute();
			 * 
			 * System.out.println("executed");
			 */

			if (algorithmId == 0) {
				resultList = jubatusProcessor.predictDefectCountRate(Integer.parseInt(userId), predictionId);
			} else if (algorithmId > 1) {
				resultList = jubatusProcessor.getPredictionResultUseCase1C(predictionId, userId, algorithmId);
			} else if (algorithmId == 1) {
				resultList = jubatusProcessor.getAllPredictionResultUseCase1C(predictionId, userId, algorithmId);
			}
		} /*
			 * catch (EtlExecutorException etlExecutorException) {
			 * log.debug("Error executing ETL file" + etlExecutorException);
			 * etlExecutorException.printStackTrace(); }
			 */ catch (Exception e1) {
			e1.printStackTrace();
		}

		return resultList;
	}

	private List<Integer> predictUseCase1D(String userId, String projectId, String predictionId, int algorithmId) {
		List<Integer> resultList = null;
		Map<String, String> properties = new HashMap<String, String>();

		try {
			/*
			 * properties.put("userId", userId); properties.put("projectId",
			 * StringUtils.valueOf(projectId)); properties.put("predictionCode",
			 * predictionId);
			 * 
			 * predictFunctionalDefectCountTelephonicaBean.setProperties(
			 * properties);
			 * predictFunctionalDefectCountTelephonicaBean.setConfiguration(null
			 * );
			 * predictFunctionalDefectCountTelephonicaBean.afterPropertiesSet();
			 * 
			 * predictFunctionalDefectCountTelephonicaBean.execute();
			 * 
			 * System.out.println("executed");
			 */

			if (algorithmId == 0) {
				resultList = jubatusProcessor.predictDensityForUseCase1D(Integer.parseInt(userId), predictionId);
			} else if (algorithmId > 1) {
				resultList = jubatusProcessor.getPredictionResultUseCase1D(predictionId, userId, algorithmId);
			} else if (algorithmId == 1) {
				resultList = jubatusProcessor.getAllPredictionResultUseCase1D(predictionId, userId, algorithmId);
			}
		} /*
			 * catch (EtlExecutorException etlExecutorException) {
			 * log.debug("Error executing ETL file" + etlExecutorException);
			 * etlExecutorException.printStackTrace(); }
			 */ catch (Exception e1) {
			e1.printStackTrace();
		}

		return resultList;
	}

	private List<Integer> predictDefectCountBoA(String userId, String projectId, String predictionId, int algorithmId) {

		if (algorithmId == 0) {
			return jubatusProcessor.predictDensityForUseCase1D(Integer.parseInt(userId), predictionId);
		} else if (algorithmId > 1) {
			return jubatusProcessor.predictDefectCountBoA(algorithmId);
		} else if (algorithmId == 1) {
			return jubatusProcessor.getAllPredictionResultUseCase1D(predictionId, userId, algorithmId);
		}
		return null;
	}

	private List<Integer> predictUseCase1(String userId, String projectId, String predictionId, int algorithmId) {
		List<Integer> resultList = null;
		Map<String, String> properties = new HashMap<String, String>();

		try {
			/*
			 * properties.put("userId", userId); properties.put("projectId",
			 * StringUtils.valueOf(projectId)); properties.put("predictionCode",
			 * predictionId);
			 * 
			 * predictDefectDensityUseCaseTelephonicaBean.setProperties(
			 * properties);
			 * predictDefectDensityUseCaseTelephonicaBean.setConfiguration(null)
			 * ;
			 * predictDefectDensityUseCaseTelephonicaBean.afterPropertiesSet();
			 * 
			 * // Execute ETL script
			 * predictDefectDensityUseCaseTelephonicaBean.execute();
			 * 
			 * System.out.println("executed");
			 */

			// Do Prediction
			if (algorithmId == 0) {
				resultList = jubatusProcessor.predictDensityForUseCase1(Integer.parseInt(userId), predictionId);
			} else if (algorithmId > 1) {
				resultList = jubatusProcessor.getPredictionResultTelephonicaUseCase1(predictionId, userId, algorithmId);
			} else if (algorithmId == 1) {
				resultList = jubatusProcessor.getAllPredictionResultTelephonicaUseCase1(predictionId, userId,
						algorithmId);
			}

		} /*
			 * catch (EtlExecutorException etlExecutorException) {
			 * log.debug("Error executing ETL file" + etlExecutorException);
			 * etlExecutorException.printStackTrace(); }
			 */ catch (Exception e1) {
			e1.printStackTrace();
		}

		return resultList;
	}

	public void setPredictLeakageBean(EtlExecutorBean predictLeakageBean) {
		this.predictLeakageBean = predictLeakageBean;
	}

	public EtlExecutorBean getPredictDefectDensityUseCaseTelephonicaBean() {
		return predictDefectDensityUseCaseTelephonicaBean;
	}

	public void setPredictDefectDensityUseCaseTelephonicaBean(
			EtlExecutorBean predictDefectDensityUseCaseTelephonicaBean) {
		this.predictDefectDensityUseCaseTelephonicaBean = predictDefectDensityUseCaseTelephonicaBean;
	}

	@Override
	public Map<String, PredictedModel> interactETLForUseCase2(String eTLType, String predictionId, String metricsId,
			String userId, int redmineProjectId) {
		if (eTLType.equalsIgnoreCase("calculateUclLcl")) {
			/*
			 * List<Double> uclLclList =
			 * retrieveUclLclData(String.valueOf(redmineProjectId),0); Map
			 * uclLclMap = new HashMap<String, PredictedModel>(); PredictedModel
			 * predictedModel = new PredictedModel();
			 * predictedModel.setUcl(uclLclList.get(1));
			 * predictedModel.setLcl(uclLclList.get(1));
			 * /*uclLclMap.put("LCL",uclLclList.get(0));
			 * uclLclMap.put("UCL",uclLclList.get(1)); uclLclMap.put(metricsId,
			 * predictedModel); return uclLclMap;
			 */
		} else if (eTLType.equalsIgnoreCase("predictUseCase2")) {
			return predictUseCase2(userId, String.valueOf(redmineProjectId), predictionId);
		}

		return null;

	}

	private Map<String, PredictedModel> predictUseCase2(String userId, String projectId, String predictionId) {
		Map<String, PredictedModel> resultList = null;
		Map<String, String> properties = new HashMap<String, String>();

		try {
			/*
			 * properties.put("userId", userId); properties.put("projectId",
			 * StringUtils.valueOf(projectId)); properties.put("predictionCode",
			 * predictionId);
			 * 
			 * defectiveModulesBean.setProperties(properties);
			 * defectiveModulesBean.setConfiguration(null);
			 * defectiveModulesBean.afterPropertiesSet();
			 * 
			 * defectiveModulesBean.execute();
			 * 
			 * System.out.println("executed");
			 */

			resultList = jubatusProcessor.predictDensityModuleWise(Integer.parseInt(userId), predictionId);
		} /*
			 * catch (EtlExecutorException etlExecutorException) {
			 * log.debug("Error executing ETL file" + etlExecutorException);
			 * etlExecutorException.printStackTrace(); }
			 */ catch (Exception e1) {
			e1.printStackTrace();
		}

		return resultList;
	}

}
